// js/app.js — app shell: top nav + screen router. Loaded as a native ES
// module from index.html, so there's no build step — this literally is
// the shipped code.

import { dbFindById, dbAll } from "./db.js";
import { renderLoginScreen } from "./screens/login.js";
import { renderTillScreen } from "./screens/till.js";
import { renderInventoryFormScreen } from "./screens/inventory-form.js";
import { renderInventoryListScreen } from "./screens/inventory-list.js";
import { renderImportScreen } from "./screens/import.js";
import { renderSettingsScreen } from "./screens/settings.js";
import { renderReportsScreen } from "./screens/reports.js";
import { renderSalesListScreen } from "./screens/sales-list.js";
import { renderEtimsQueueScreen } from "./screens/etims-queue.js";
import { resetTillState } from "./till-state.js";
import { getFeatureFlags } from "./sales.js";
import { applyTheme } from "./theme.js";

const appEl = document.getElementById("app");

let currentUser = null;
let currentTab = "till";

// Single account, so every tab is always visible — no role gating needed.
const TABS = [
  { key: "till", label: "Till" },
  { key: "sales", label: "Sales" },
  { key: "inventory", label: "Inventory" },
  { key: "add-product", label: "Add product" },
  { key: "import", label: "Bulk import" },
  { key: "reports", label: "Z-Report" },
  { key: "etims", label: "eTIMS" },
  { key: "settings", label: "Settings" },
];

async function boot() {
  registerServiceWorker();
  await restoreSavedTheme();
  showLogin();
}

async function restoreSavedTheme() {
  // A store row may already exist from a previous session (IndexedDB
  // persists across launches) — apply its saved theme immediately, before
  // login, so the branding/dark-mode choice is consistent from first paint.
  try {
    const stores = await dbAll("stores");
    const store = stores[0];
    if (store) {
      const flags = getFeatureFlags(store);
      applyTheme(store.theme_primary, flags.darkMode);
    }
  } catch { /* first run, no stores yet — fine */ }
}

function showLogin() {
  appEl.innerHTML = "";
  renderLoginScreen(appEl, (user) => {
    currentUser = user;
    currentTab = "till";
    showApp();
  });
}

async function showApp() {
  const store = await dbFindById("stores", currentUser.storeId);
  applyTheme(store?.theme_primary, getFeatureFlags(store).darkMode);

  appEl.innerHTML = `
    <div style="height:100%;display:flex;flex-direction:column">
      <nav class="topnav">
        <span class="brand">${escapeHtml(store?.name || "Lacianda POS")}</span>
        <div id="tabs"></div>
        <div class="spacer"></div>
        <span class="text-sm muted">${escapeHtml(currentUser.fullName)}
          <button id="logout" class="btn-ghost btn-sm" style="text-decoration:underline">Log out</button>
        </span>
      </nav>
      <div class="screen" id="screen-root"></div>
    </div>
  `;

  const tabsEl = appEl.querySelector("#tabs");
  tabsEl.innerHTML = TABS.map((t) => `<button class="tab ${currentTab === t.key ? "active" : ""}" data-tab="${t.key}">${t.label}</button>`).join("");
  tabsEl.querySelectorAll("[data-tab]").forEach((btn) => {
    btn.addEventListener("click", () => { currentTab = btn.dataset.tab; showApp(); });
  });

  appEl.querySelector("#logout").addEventListener("click", () => {
    currentUser = null;
    resetTillState();
    showLogin();
  });

  await renderScreen(appEl.querySelector("#screen-root"));
}

async function renderScreen(root) {
  try {
    switch (currentTab) {
      case "till": return await renderTillScreen(root, currentUser);
      case "sales": return await renderSalesListScreen(root, currentUser);
      case "inventory": return await renderInventoryListScreen(root, currentUser);
      case "add-product": return await renderInventoryFormScreen(root, currentUser);
      case "import": return await renderImportScreen(root, currentUser);
      case "reports": return await renderReportsScreen(root, currentUser, handleShiftClosed);
      case "etims": return await renderEtimsQueueScreen(root, currentUser);
      case "settings": return await renderSettingsScreen(root, currentUser);
      default: return await renderTillScreen(root, currentUser);
    }
  } catch (err) {
    console.error("Screen render failed:", err);
    root.innerHTML = `
      <div class="screen-pad">
        <div class="card"><div class="card-body">
          <p class="font-bold" style="color:var(--danger)">Something went wrong loading this screen.</p>
          <p class="text-sm muted mt-1">${escapeHtml(err.message || String(err))}</p>
          <button class="btn btn-outline mt-2" id="retry-render">Try again</button>
        </div></div>
      </div>
    `;
    root.querySelector("#retry-render")?.addEventListener("click", () => renderScreen(root));
  }
}

function handleShiftClosed() {
  currentUser = null;
  currentTab = "till";
  resetTillState();
  showLogin();
}

function registerServiceWorker() {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js").catch((err) => {
      console.warn("Service worker registration failed (app still works, just won't cache for full offline reload):", err);
    });
  }
}

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

boot();
