// js/sales.js — checkout, split tenders across M-Pesa Personal/Till/
// Paybill/Pochi/STK modes, configurable VAT/catering levy with per-item
// eTIMS tax-type awareness (via money.js's computeSaleTotals).

import { dbInsert, dbUpdate, dbQuery, dbFindById, generateId, nowIso } from "./db.js";
import { computeSaleTotals, DEFAULT_VAT_RATE_PCT, DEFAULT_CATERING_LEVY_RATE_PCT } from "./money.js";
import { deductStockForSale, restockVariant, InsufficientStockError } from "./inventory.js";

async function nextReceiptNumber(storeId) {
  const sales = await dbQuery("sales", { store_id: storeId });
  const today = new Date();
  const stamp = today.toISOString().slice(0, 10).replace(/-/g, "");
  const todayPrefix = today.toISOString().slice(0, 10);
  const count = sales.filter((s) => s.created_at.startsWith(todayPrefix)).length;
  return `LWS-${stamp}-${String(count + 1).padStart(4, "0")}`;
}

/**
 * cart: [{ variantId, productId, label, quantity, unitPriceCents, isWholesale, lineTotalCents, variant, taxType }]
 * tender: { cashCents, mpesaCents, cardCents, mpesaMode, mpesaNote, mpesaStkVerified }
 *   mpesaMode: 'personal' | 'till' | 'paybill' | 'pochi' | 'stk'
 * billing: { vatEnabled, vatRatePct, cateringLevyEnabled, cateringLevyRatePct }
 */
export async function checkout(storeId, cashierId, shiftId, cart, discountCents, tender, billing) {
  if (cart.length === 0) throw new Error("Cart is empty");

  const totals = computeSaleTotals(cart, discountCents, billing);

  const { cashCents = 0, mpesaCents = 0, cardCents = 0, mpesaMode, mpesaNote, mpesaStkVerified } = tender;
  const tendered = cashCents + mpesaCents + cardCents;
  if (tendered < totals.totalCents) {
    throw new Error(`Amount tendered is short by ${((totals.totalCents - tendered) / 100).toFixed(2)} KES.`);
  }

  const now = nowIso();
  const saleId = generateId();
  const receiptNumber = await nextReceiptNumber(storeId);

  const store = await dbFindById("stores", storeId);
  const etimsEnabled = getFeatureFlags(store).etimsEnabled;

  const sale = {
    id: saleId, store_id: storeId, cashier_id: cashierId, shift_id: shiftId,
    subtotal_cents: totals.subtotalCents, vat_cents: totals.vatCents, vat_rate_pct: totals.vatRatePct,
    catering_levy_cents: totals.cateringLevyCents, catering_levy_rate_pct: totals.cateringLevyRatePct,
    discount_cents: discountCents, total_cents: totals.totalCents,
    cash_tendered_cents: cashCents, mpesa_tendered_cents: mpesaCents, card_tendered_cents: cardCents,
    mpesa_mode: mpesaCents > 0 ? (mpesaMode || "personal") : null,
    mpesa_note: mpesaCents > 0 ? (mpesaNote || null) : null,
    mpesa_stk_verified: Boolean(mpesaStkVerified),
    status: "completed", receipt_number: receiptNumber, created_at: now, updated_at: now,
    etims_status: etimsEnabled ? "pending" : "not_required",
  };
  await dbInsert("sales", sale);

  const items = [];
  for (const line of cart) {
    const item = {
      id: generateId(), sale_id: saleId, variant_id: line.variantId, quantity: line.quantity,
      unit_price_cents: line.unitPriceCents, was_wholesale_price: line.isWholesale,
      tax_type: line.taxType || "standard",
      line_total_cents: line.lineTotalCents, updated_at: now,
    };
    await dbInsert("sale_items", item);
    items.push(item);

    try {
      await deductStockForSale(storeId, line.variant, line.quantity, saleId, cashierId);
    } catch (err) {
      if (err instanceof InsufficientStockError) throw new Error(`${line.label}: ${err.message}`);
      throw err;
    }
  }

  return { sale, items, changeDueCents: tendered - totals.totalCents };
}

/**
 * Voids a completed sale. `restock: true` reverses the stock deduction for
 * every line via a 'correction' movement — kept explicit and opt-in rather
 * than automatic, since a void might mean "customer changed their mind,
 * bottle goes back on the shelf" or "till error, bottle already broke" —
 * those are physically different outcomes a human should choose between.
 */
export async function voidSale(storeId, saleId, reason, voidedBy, restock) {
  const sale = await dbFindById("sales", saleId);
  if (!sale) throw new Error("Sale not found");
  if (sale.status !== "completed") throw new Error(`Sale is already ${sale.status}`);

  await dbUpdate("sales", saleId, { status: "voided", void_reason: reason, voided_by: voidedBy, updated_at: nowIso() });

  if (restock) {
    const items = await dbQuery("sale_items", { sale_id: saleId });
    for (const item of items) {
      const variant = await dbFindById("product_variants", item.variant_id);
      if (variant) await restockVariant(storeId, variant, item.quantity, voidedBy, "correction");
    }
  }
}

export function getFeatureFlags(store) {
  const defaults = {
    allowNegativeStock: false,
    requirePinForVoid: true,
    requirePinForDiscount: false,
    autoPrintReceipt: true,
    darkMode: false,
    vatEnabled: true,
    vatRatePct: DEFAULT_VAT_RATE_PCT,
    cateringLevyEnabled: true,
    cateringLevyRatePct: DEFAULT_CATERING_LEVY_RATE_PCT,
    receiptWidth: "58mm",
    // M-Pesa payment modes — any combination can be enabled at once;
    // the till shows a picker only when more than one is on ("auto
    // multi-mode"), otherwise it just shows the one that's configured.
    mpesaPersonalEnabled: true,
    mpesaTillEnabled: false,
    mpesaTillNumber: "",
    mpesaPaybillEnabled: false,
    mpesaPaybillNumber: "",
    mpesaPaybillAccount: "",
    mpesaPochiEnabled: false,
    mpesaPochiNumber: "",
    // STK Push needs a paired backend server holding real Daraja
    // credentials — this app only ever talks to the URL you configure.
    stkPushEnabled: false,
    stkPushBackendUrl: "",
    // KRA eTIMS staging — see js/etims.js for what this actually means
    // without an approved submission middleware.
    etimsEnabled: false,
    kraPin: "",
  };
  try { return { ...defaults, ...JSON.parse(store?.feature_flags || "{}") }; } catch { return defaults; }
}
