// js/seed-data.js — same catalog as the full source drop's
// packages/core/src/modules/inventory/seed.ts, ported to plain JS.
// PRICES ARE PLACEHOLDER ESTIMATES (KES) — adjust to Lacianda's actual
// supplier invoices before real use.

function bottleAndCrate(bottleLabel, volumeMl, costKes, retailKes, crateSize, crateCostKes, crateRetailKes, wholesaleKes, wholesaleThreshold = 12) {
  return [
    { variantLabel: bottleLabel, volumeMl, baseUnits: 1, costKes, retailKes, wholesaleKes, wholesaleQtyThreshold: wholesaleThreshold, reorderLevel: crateSize, initialStock: crateSize * 4 },
    { variantLabel: `Crate of ${crateSize}`, volumeMl, baseUnits: crateSize, costKes: crateCostKes, retailKes: crateRetailKes, wholesaleKes: crateRetailKes },
  ];
}

export const CATEGORY_ORDER = ["Beer", "Whiskey", "Vodka", "Gin", "Spirits", "Wine", "Extras"];

export const CATALOG = [
  { brand: "White Cap", name: "White Cap Lager 500ml", category: "Beer", variants: bottleAndCrate("500ml", 500, 130, 180, 25, 3250, 4250, 150) },
  { brand: "Tusker", name: "Tusker Lager 500ml", category: "Beer", variants: bottleAndCrate("500ml", 500, 140, 200, 25, 3500, 4650, 170) },
  { brand: "Tusker", name: "Tusker Malt 500ml", category: "Beer", variants: bottleAndCrate("500ml", 500, 160, 220, 25, 4000, 5150, 190) },
  { brand: "Tusker", name: "Tusker Cider 500ml", category: "Beer", variants: bottleAndCrate("500ml", 500, 150, 210, 25, 3750, 4900, 180) },
  { brand: "Guinness", name: "Guinness Smooth 500ml", category: "Beer", variants: bottleAndCrate("500ml", 500, 160, 230, 25, 4000, 5350, 195) },
  { brand: "Balozi", name: "Balozi Lager 500ml", category: "Beer", variants: bottleAndCrate("500ml", 500, 120, 170, 25, 3000, 4025, 145) },

  { brand: "Johnnie Walker", name: "Johnnie Walker Red Label", category: "Whiskey", variants: [
    { variantLabel: "250ml", volumeMl: 250, baseUnits: 1, costKes: 650, retailKes: 900, wholesaleKes: 800, wholesaleQtyThreshold: 6, reorderLevel: 6, initialStock: 24 },
    { variantLabel: "750ml", volumeMl: 750, baseUnits: 3, costKes: 1800, retailKes: 2500, wholesaleKes: 2300, wholesaleQtyThreshold: 6 },
  ]},
  { brand: "Johnnie Walker", name: "Johnnie Walker Black Label", category: "Whiskey", variants: [
    { variantLabel: "750ml", volumeMl: 750, baseUnits: 1, costKes: 3200, retailKes: 4200, wholesaleKes: 3900, wholesaleQtyThreshold: 6, reorderLevel: 6, initialStock: 12 },
  ]},
  { brand: "Jameson", name: "Jameson Irish Whiskey", category: "Whiskey", variants: [
    { variantLabel: "250ml", volumeMl: 250, baseUnits: 1, costKes: 800, retailKes: 1100, wholesaleKes: 980, wholesaleQtyThreshold: 6, reorderLevel: 6, initialStock: 24 },
    { variantLabel: "750ml", volumeMl: 750, baseUnits: 3, costKes: 2200, retailKes: 2900, wholesaleKes: 2650, wholesaleQtyThreshold: 6 },
  ]},

  { brand: "Chrome", name: "Chrome Vodka", category: "Vodka", variants: [
    { variantLabel: "250ml", volumeMl: 250, baseUnits: 1, costKes: 250, retailKes: 350, wholesaleKes: 310, wholesaleQtyThreshold: 12, reorderLevel: 12, initialStock: 48 },
    { variantLabel: "350ml", volumeMl: 350, baseUnits: 1, costKes: 330, retailKes: 450, wholesaleKes: 400, wholesaleQtyThreshold: 12 },
  ]},
  { brand: "Kibao", name: "Kibao Vodka 250ml", category: "Vodka", variants: [
    { variantLabel: "250ml", volumeMl: 250, baseUnits: 1, costKes: 200, retailKes: 280, wholesaleKes: 250, wholesaleQtyThreshold: 12, reorderLevel: 12, initialStock: 48 },
  ]},
  { brand: "Smirnoff", name: "Smirnoff Vodka", category: "Vodka", variants: [
    { variantLabel: "250ml", volumeMl: 250, baseUnits: 1, costKes: 500, retailKes: 700, wholesaleKes: 630, wholesaleQtyThreshold: 6, reorderLevel: 6, initialStock: 24 },
    { variantLabel: "750ml", volumeMl: 750, baseUnits: 3, costKes: 1400, retailKes: 1900, wholesaleKes: 1750, wholesaleQtyThreshold: 6 },
  ]},

  { brand: "Chrome", name: "Chrome Gin 250ml", category: "Gin", variants: [
    { variantLabel: "250ml", volumeMl: 250, baseUnits: 1, costKes: 250, retailKes: 350, wholesaleKes: 310, wholesaleQtyThreshold: 12, reorderLevel: 12, initialStock: 48 },
  ]},
  { brand: "Kane Extra", name: "Kane Extra Gin 250ml", category: "Gin", variants: [
    { variantLabel: "250ml", volumeMl: 250, baseUnits: 1, costKes: 220, retailKes: 300, wholesaleKes: 270, wholesaleQtyThreshold: 12, reorderLevel: 12, initialStock: 48 },
  ]},
  { brand: "Best Gin", name: "Best Gin 250ml", category: "Gin", variants: [
    { variantLabel: "250ml", volumeMl: 250, baseUnits: 1, costKes: 200, retailKes: 280, wholesaleKes: 250, wholesaleQtyThreshold: 12, reorderLevel: 12, initialStock: 48 },
  ]},
  { brand: "Gilbey's", name: "Gilbey's Gin", category: "Gin", variants: [
    { variantLabel: "250ml", volumeMl: 250, baseUnits: 1, costKes: 480, retailKes: 650, wholesaleKes: 590, wholesaleQtyThreshold: 6, reorderLevel: 6, initialStock: 24 },
    { variantLabel: "750ml", volumeMl: 750, baseUnits: 3, costKes: 1300, retailKes: 1800, wholesaleKes: 1650, wholesaleQtyThreshold: 6 },
  ]},

  { brand: "Kenya Cane", name: "Kenya Cane", category: "Spirits", variants: [
    { variantLabel: "250ml", volumeMl: 250, baseUnits: 1, costKes: 180, retailKes: 250, wholesaleKes: 220, wholesaleQtyThreshold: 12, reorderLevel: 12, initialStock: 48 },
    { variantLabel: "350ml", volumeMl: 350, baseUnits: 1, costKes: 240, retailKes: 330, wholesaleKes: 300, wholesaleQtyThreshold: 12 },
  ]},
  { brand: "Captain Morgan", name: "Captain Morgan Spiced Rum 750ml", category: "Spirits", variants: [
    { variantLabel: "750ml", volumeMl: 750, baseUnits: 1, costKes: 1900, retailKes: 2500, wholesaleKes: 2300, wholesaleQtyThreshold: 6, reorderLevel: 6, initialStock: 12 },
  ]},

  { brand: "Four Cousins", name: "Four Cousins 750ml", category: "Wine", variants: [
    { variantLabel: "750ml", volumeMl: 750, baseUnits: 1, costKes: 750, retailKes: 1100, wholesaleKes: 980, wholesaleQtyThreshold: 6, reorderLevel: 6, initialStock: 24 },
  ]},
  { brand: "Frontera", name: "Frontera 750ml", category: "Wine", variants: [
    { variantLabel: "750ml", volumeMl: 750, baseUnits: 1, costKes: 700, retailKes: 1000, wholesaleKes: 900, wholesaleQtyThreshold: 6, reorderLevel: 6, initialStock: 24 },
  ]},
  { brand: "Robertson", name: "Robertson Winery 750ml", category: "Wine", variants: [
    { variantLabel: "750ml", volumeMl: 750, baseUnits: 1, costKes: 800, retailKes: 1150, wholesaleKes: 1030, wholesaleQtyThreshold: 6, reorderLevel: 6, initialStock: 24 },
  ]},
  { brand: "Cellar Cask", name: "Cellar Cask 5L Box", category: "Wine", variants: [
    { variantLabel: "5L Box", volumeMl: 5000, baseUnits: 1, costKes: 1600, retailKes: 2200, wholesaleKes: 2000, wholesaleQtyThreshold: 4, reorderLevel: 4, initialStock: 12 },
  ]},
  { brand: "Asconi", name: "Asconi 750ml", category: "Wine", variants: [
    { variantLabel: "750ml", volumeMl: 750, baseUnits: 1, costKes: 850, retailKes: 1200, wholesaleKes: 1080, wholesaleQtyThreshold: 6, reorderLevel: 6, initialStock: 24 },
  ]},
];
