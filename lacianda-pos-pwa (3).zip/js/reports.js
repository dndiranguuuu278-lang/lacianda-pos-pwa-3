// js/reports.js — end-of-day Z-Report, computed entirely from IndexedDB.

import { dbQuery } from "./db.js";
import { getLowStockProducts } from "./inventory.js";

export async function computeZReport(storeId, { shiftId } = {}) {
  const allSales = await dbQuery("sales", { store_id: storeId });
  const inScope = shiftId ? allSales.filter((s) => s.shift_id === shiftId) : allSales;

  const completed = inScope.filter((s) => s.status === "completed");
  const voided = inScope.filter((s) => s.status === "voided");
  const sum = (fn) => completed.reduce((acc, s) => acc + fn(s), 0);

  return {
    grossRevenueCents: sum((s) => s.total_cents),
    cashTotalCents: sum((s) => s.cash_tendered_cents),
    mpesaTotalCents: sum((s) => s.mpesa_tendered_cents),
    cardTotalCents: sum((s) => s.card_tendered_cents),
    vatCollectedCents: sum((s) => s.vat_cents),
    cateringLevyCollectedCents: sum((s) => s.catering_levy_cents),
    discountsGivenCents: sum((s) => s.discount_cents),
    saleCount: completed.length,
    voidedCount: voided.length,
    lowStockItems: await getLowStockProducts(storeId),
  };
}

export function calcCashVariance(openingFloatCents, cashSalesCents, countedCashCents) {
  const expectedCents = openingFloatCents + cashSalesCents;
  return { expectedCents, varianceCents: countedCashCents - expectedCents };
}
