// js/theme.js — applies the shop's chosen accent color and light/dark
// mode to the document. Shared between app boot (restoring a previously
// saved theme) and Settings (applying a live change).

export function applyTheme(color, darkMode) {
  if (color) {
    document.documentElement.style.setProperty("--primary", color);
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", color);
  }
  document.documentElement.setAttribute("data-theme", darkMode ? "dark" : "light");
}
