// js/receipt.js — the print system. `buildReceiptHtml` renders the receipt
// once; `showReceiptModal` displays it on-screen (for reprints from the
// Sales list, or "View" from the post-checkout toast), and `printReceipt`
// sends it straight to a print window without showing anything on-screen
// first — used for the auto-print-and-move-on checkout flow so ringing up
// the next customer is never blocked on a modal.

import { dbFindById, dbQuery } from "./db.js";
import { formatKes } from "./money.js";
import { getFeatureFlags } from "./sales.js";

const WIDTH_MM = { "58mm": 220, "80mm": 300 }; // approx px width for common thermal-printer paper sizes

async function buildReceiptHtml(storeId, sale) {
  const store = await dbFindById("stores", storeId);
  const items = await dbQuery("sale_items", { sale_id: sale.id });

  const lines = [];
  for (const item of items) {
    const variant = await dbFindById("product_variants", item.variant_id);
    const product = variant ? await dbFindById("products", variant.product_id) : null;
    lines.push({
      label: `${product?.name ?? "Item"} — ${variant?.variant_label ?? ""}`,
      quantity: item.quantity,
      unitPriceCents: item.unit_price_cents,
      lineTotalCents: item.line_total_cents,
      isWholesale: item.was_wholesale_price,
    });
  }

  // Older sales (from before configurable billing) won't have a stored
  // rate — fall back to a plain label rather than showing "undefined%".
  const vatLabel = sale.vat_rate_pct != null ? `VAT (${sale.vat_rate_pct}%)` : "VAT";
  const levyLabel = sale.catering_levy_rate_pct != null ? `Catering levy (${sale.catering_levy_rate_pct}%)` : "Catering levy";

  const html = `
    <div style="text-align:center;margin-bottom:10px">
      <div class="font-bold" style="font-size:16px">${escapeHtml(store?.name || "Lacianda Wines and Spirits")}</div>
      <div>${escapeHtml(store?.phone_number || "")}</div>
    </div>
    <div style="border-top:1px dashed #999;border-bottom:1px dashed #999;padding:6px 0;margin-bottom:8px">
      <div>Receipt: ${escapeHtml(sale.receipt_number || sale.id)}</div>
      <div>Date: ${new Date(sale.created_at).toLocaleString()}</div>
    </div>
    <table style="width:100%;border-collapse:collapse">
      ${lines.map((l) => `
        <tr><td colspan="2" style="padding-top:4px">${escapeHtml(l.label)}${l.isWholesale ? ' <span style="font-size:10px">(wholesale)</span>' : ""}</td></tr>
        <tr><td>${l.quantity} × ${formatKes(l.unitPriceCents)}</td><td style="text-align:right">${formatKes(l.lineTotalCents)}</td></tr>
      `).join("")}
    </table>
    <div style="border-top:1px dashed #999;margin-top:8px;padding-top:6px">
      <div class="row-between"><span>Subtotal</span><span>${formatKes(sale.subtotal_cents)}</span></div>
      ${sale.discount_cents ? `<div class="row-between"><span>Discount</span><span>-${formatKes(sale.discount_cents)}</span></div>` : ""}
      ${sale.vat_cents ? `<div class="row-between"><span>${vatLabel}</span><span>${formatKes(sale.vat_cents)}</span></div>` : ""}
      ${sale.catering_levy_cents ? `<div class="row-between"><span>${levyLabel}</span><span>${formatKes(sale.catering_levy_cents)}</span></div>` : ""}
      <div class="row-between font-bold" style="font-size:15px;border-top:1px solid #333;margin-top:4px;padding-top:4px"><span>TOTAL</span><span>${formatKes(sale.total_cents)}</span></div>
    </div>
    <div style="margin-top:8px">
      ${sale.cash_tendered_cents ? `<div class="row-between"><span>Cash</span><span>${formatKes(sale.cash_tendered_cents)}</span></div>` : ""}
      ${sale.mpesa_tendered_cents ? `<div class="row-between"><span>M-Pesa${mpesaModeLabel(sale.mpesa_mode)}${sale.mpesa_note ? " — " + escapeHtml(sale.mpesa_note) : ""}</span><span>${formatKes(sale.mpesa_tendered_cents)}</span></div>` : ""}
      ${sale.card_tendered_cents ? `<div class="row-between"><span>Card</span><span>${formatKes(sale.card_tendered_cents)}</span></div>` : ""}
    </div>
    <div style="text-align:center;margin-top:12px;font-size:12px">${escapeHtml(store?.receipt_header || "Thank you for your business!")}</div>
  `;

  return { html, receiptWidthPx: WIDTH_MM[getFeatureFlags(store).receiptWidth] || WIDTH_MM["58mm"] };
}

/** On-screen receipt with Print/Close buttons — used for reprints and manual "View". */
export async function showReceiptModal(storeId, sale, { autoPrint = false } = {}) {
  const { html, receiptWidthPx } = await buildReceiptHtml(storeId, sale);

  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.innerHTML = `
    <div class="modal" id="receipt-modal" style="width:${receiptWidthPx}px;max-width:92vw">
      <button class="modal-close no-print" id="rc-close">✕</button>
      <div id="receipt-content" style="font-family:'Courier New',monospace;font-size:13px">${html}</div>
      <div class="row no-print" style="justify-content:center;gap:8px;margin-top:14px">
        <button class="btn btn-outline no-print" id="rc-close-btn">Close</button>
        <button class="btn no-print" id="rc-print">Print receipt</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);

  function close() { backdrop.remove(); }
  backdrop.querySelector("#rc-close").addEventListener("click", close);
  backdrop.querySelector("#rc-close-btn").addEventListener("click", close);
  backdrop.querySelector("#rc-print").addEventListener("click", () => openPrintWindow(html, receiptWidthPx));

  if (autoPrint) setTimeout(() => openPrintWindow(html, receiptWidthPx), 300);

  return { close };
}

/** Silent print with no on-screen modal — the default post-checkout path when auto-print is enabled. */
export async function printReceipt(storeId, sale) {
  const { html, receiptWidthPx } = await buildReceiptHtml(storeId, sale);
  openPrintWindow(html, receiptWidthPx);
}

function openPrintWindow(html, widthPx) {
  const printWindow = window.open("", "_blank", `width=${widthPx + 40},height=600`);
  if (!printWindow) return; // popup blocked — reachable again via Sales list > View
  printWindow.document.write(`
    <html><head><title>Receipt</title>
    <style>
      body { font-family: 'Courier New', monospace; font-size: 13px; padding: 12px; width: ${widthPx}px; margin: 0 auto; }
      .row-between { display: flex; justify-content: space-between; }
      .font-bold { font-weight: 700; }
      table { width: 100%; border-collapse: collapse; }
    </style>
    </head><body>${html}</body></html>
  `);
  printWindow.document.close();
  printWindow.focus();
  printWindow.onload = () => { printWindow.print(); };
  setTimeout(() => { try { printWindow.print(); } catch { /* already printed or closed */ } }, 400);
}

function escapeHtml(s) {
  return (s || "").toString().replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function mpesaModeLabel(mode) {
  const labels = { personal: " (Personal)", till: " (Buy Goods)", paybill: " (Paybill)", pochi: " (Pochi la Biashara)" };
  return labels[mode] || "";
}
