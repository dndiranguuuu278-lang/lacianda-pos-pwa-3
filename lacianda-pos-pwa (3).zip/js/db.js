// js/db.js — IndexedDB data layer.
//
// This IS the local-first database for this build: every read/write in the
// app goes through here, IndexedDB persists it to disk in the browser's
// profile, and it survives closing the tab/app, losing network, or a full
// machine reboot. It mirrors the same table shapes as the SQLite/Postgres
// design in the full source drop (client-side UUID PKs, is_synced,
// updated_at) so this data model could sync to that same cloud schema
// later — this build just doesn't include the network sync leg, since
// that requires a live server this sandbox can't stand up.

const DB_NAME = "lacianda_pos";
const DB_VERSION = 1;

const STORES = [
  "stores", "users", "shifts", "categories", "brands", "products",
  "product_variants", "inventory_stock", "stock_movements", "sales",
  "sale_items",
];

let dbPromise = null;

export function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const name of STORES) {
        if (!db.objectStoreNames.contains(name)) {
          db.createObjectStore(name, { keyPath: name === "stores" ? "id" : "id" });
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

function tx(db, storeName, mode) {
  return db.transaction(storeName, mode).objectStore(storeName);
}

export async function dbInsert(storeName, row) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = tx(db, storeName, "readwrite").add(row);
    req.onsuccess = () => resolve(row);
    req.onerror = () => reject(req.error);
  });
}

export async function dbPut(storeName, row) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = tx(db, storeName, "readwrite").put(row);
    req.onsuccess = () => resolve(row);
    req.onerror = () => reject(req.error);
  });
}

export async function dbUpdate(storeName, id, patch) {
  const db = await openDb();
  const existing = await dbFindById(storeName, id);
  if (!existing) throw new Error(`${storeName} row ${id} not found`);
  const updated = { ...existing, ...patch };
  return dbPut(storeName, updated);
}

export async function dbFindById(storeName, id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = tx(db, storeName, "readonly").get(id);
    req.onsuccess = () => resolve(req.result ?? null);
    req.onerror = () => reject(req.error);
  });
}

export async function dbAll(storeName) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = tx(db, storeName, "readonly").getAll();
    req.onsuccess = () => resolve(req.result ?? []);
    req.onerror = () => reject(req.error);
  });
}

/** Simple in-memory filter over getAll() — the dataset for a single shop is small enough that this is plenty fast without building real indexes for every field. */
export async function dbQuery(storeName, where = {}) {
  const rows = await dbAll(storeName);
  const keys = Object.keys(where);
  if (keys.length === 0) return rows;
  return rows.filter((r) => keys.every((k) => r[k] === where[k]));
}

export async function dbDelete(storeName, id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = tx(db, storeName, "readwrite").delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export function generateId() {
  return crypto.randomUUID();
}

export function nowIso() {
  return new Date().toISOString();
}
