// js/auth.js — offline PIN hashing/verification via Web Crypto (PBKDF2).
// Identical approach to the full source drop's packages/core/src/auth/pin-auth.ts.

const ITERATIONS = 100_000;

async function deriveBits(pin, salt) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(pin), "PBKDF2", false, ["deriveBits"]);
  return crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: ITERATIONS, hash: "SHA-256" }, keyMaterial, 256);
}

function toHex(buf) {
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function fromHex(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
  return bytes;
}

export async function hashPin(pin) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const derived = await deriveBits(pin, salt);
  return `pbkdf2$${toHex(salt)}$${toHex(derived)}`;
}

export async function verifyPin(pin, storedHash) {
  const [scheme, saltHex, hashHex] = (storedHash || "").split("$");
  if (scheme !== "pbkdf2" || !saltHex || !hashHex) return false;
  const derived = await deriveBits(pin, fromHex(saltHex));
  return toHex(derived) === hashHex;
}
