// js/stk-push.js — STK Push client.
//
// HONEST SCOPE: Safaricom's Daraja API cannot be called directly from a
// browser — it doesn't support CORS for browser requests, and even if it
// did, your consumer secret would be sitting in client-side JS for anyone
// to read. This client instead calls a backend URL YOU configure in
// Settings, using the same request/response shape as the reference server
// in the full source-drop of this project (server/src/routes/mpesa.
// stkpush.js and mpesa.status.js) — point stkPushBackendUrl at a server
// running that code (or your own equivalent) and this works for real. With
// no backend configured, initiate() throws immediately with a clear
// message rather than hanging or pretending to succeed.

export class StkPushNotConfiguredError extends Error {
  constructor() {
    super("STK Push isn't set up yet — add your backend URL in Settings > M-Pesa, or use Till/Paybill/Personal number instead.");
    this.name = "StkPushNotConfiguredError";
  }
}

export async function initiateStkPush(backendUrl, { phoneNumber, amountKes, saleId }) {
  if (!backendUrl) throw new StkPushNotConfiguredError();

  const normalizedPhone = phoneNumber.trim().replace(/^0/, "254").replace(/^\+/, "");
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000); // don't let an unresponsive host hang the till indefinitely

  let res;
  try {
    res = await fetch(`${backendUrl.replace(/\/$/, "")}/mpesa/stk-push`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone_number: normalizedPhone, amount: amountKes, sale_id: saleId }),
      signal: controller.signal,
    });
  } catch (err) {
    if (err.name === "AbortError") {
      throw new Error(`No response from ${backendUrl} after 10s — check the URL in Settings and that the server is running.`);
    }
    throw new Error(`Couldn't reach ${backendUrl} — check the URL in Settings and that the server is running.`);
  } finally {
    clearTimeout(timeoutId);
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `STK Push request failed (${res.status}).`);
  }
  return res.json(); // { checkoutRequestId, merchantRequestId, responseDescription }
}

export async function pollStkStatus(backendUrl, checkoutRequestId) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);
  let res;
  try {
    res = await fetch(`${backendUrl.replace(/\/$/, "")}/mpesa/stk-status/${checkoutRequestId}`, { signal: controller.signal });
  } catch (err) {
    throw new Error(err.name === "AbortError" ? "Status check timed out." : "Status check failed — network error.");
  } finally {
    clearTimeout(timeoutId);
  }
  if (!res.ok) throw new Error(`Status check failed (${res.status}).`);
  return res.json(); // { status: 'pending'|'success'|'failed', mpesaCode? }
}

/**
 * Polls until success/failed or timeout. Calls onTick(status) after every
 * poll so the UI can show "waiting for customer..." live.
 */
export async function waitForStkResult(backendUrl, checkoutRequestId, { intervalMs = 2500, timeoutMs = 60000, onTick } = {}) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const result = await pollStkStatus(backendUrl, checkoutRequestId);
    onTick?.(result);
    if (result.status === "success" || result.status === "failed") return result;
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  return { status: "failed", reason: "timeout" };
}
