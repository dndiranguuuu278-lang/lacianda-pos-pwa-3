// js/permissions.js — PIN confirmation gate for sensitive actions (voiding
// a sale, applying a discount). With a single account, this simply
// re-checks the owner's own PIN — a deliberate "are you sure, prove it"
// step, not a separate-person approval like a multi-staff system would need.

import { dbQuery } from "./db.js";
import { verifyPin } from "./auth.js";

/** Resolves the account if the PIN matches, else null. */
export async function verifyOwnerPin(storeId, candidatePin) {
  const users = await dbQuery("users", { store_id: storeId, is_active: true });
  for (const u of users) {
    if (await verifyPin(candidatePin, u.pin_hash)) return u;
  }
  return null;
}

/**
 * Shows a small PIN-entry modal and resolves with the account, or null if
 * cancelled. Used as a blocking gate before a sensitive action.
 */
export function requestPinConfirmation(storeId, reasonText) {
  return new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal" style="width:320px;text-align:center">
        <button class="modal-close" id="mp-close">✕</button>
        <h2>Confirm with your PIN</h2>
        <p class="text-sm muted mb-2">${escapeHtml(reasonText)}</p>
        <input id="mp-pin" class="input" type="password" inputmode="numeric" maxlength="4" placeholder="PIN" style="text-align:center;font-size:20px;letter-spacing:6px" autofocus />
        <div id="mp-error" class="text-sm mt-1" style="color:var(--danger)"></div>
        <button id="mp-confirm" class="btn btn-block mt-2">Confirm</button>
      </div>
    `;
    document.body.appendChild(backdrop);
    const pinInput = backdrop.querySelector("#mp-pin");
    const errorEl = backdrop.querySelector("#mp-error");
    pinInput.focus();

    function close(result) {
      backdrop.remove();
      resolve(result);
    }
    backdrop.querySelector("#mp-close").addEventListener("click", () => close(null));

    async function attempt() {
      const pin = pinInput.value.trim();
      if (pin.length < 4) return;
      const user = await verifyOwnerPin(storeId, pin);
      if (!user) {
        errorEl.textContent = "That's not the correct PIN.";
        pinInput.value = "";
        pinInput.focus();
        return;
      }
      close(user);
    }
    backdrop.querySelector("#mp-confirm").addEventListener("click", attempt);
    pinInput.addEventListener("keydown", (e) => { if (e.key === "Enter") attempt(); });
  });
}

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
