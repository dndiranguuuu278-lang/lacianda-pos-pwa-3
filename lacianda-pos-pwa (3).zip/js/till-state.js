// js/till-state.js — module-level (singleton) cart state, shared across
// re-renders of the Till screen. Without this, navigating to another tab
// and back would silently wipe an in-progress sale, since renderTillScreen
// would otherwise start a fresh local `cart = []` on every render.

export const tillState = {
  cart: [],
  discountKes: 0,
};

export function resetTillState() {
  tillState.cart = [];
  tillState.discountKes = 0;
}
