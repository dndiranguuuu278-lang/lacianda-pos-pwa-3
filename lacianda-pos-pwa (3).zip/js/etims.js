// js/etims.js — KRA eTIMS invoice staging.
//
// HONEST SCOPE: this does not, and cannot, submit directly to KRA. eTIMS
// requires an approved OSCU/TIS device or KRA-certified middleware
// regardless of what app architecture sits in front of it — that's a KRA
// requirement, not a limitation of this being an offline PWA. What this
// module DOES do: classify every sale line by tax type (standard /
// zero-rated / exempt) at the point of sale, compute VAT correctly per
// line, generate the invoice number and payload shape KRA's systems
// expect, and keep a queue of pending invoices you can export and hand to
// your approved eTIMS software/accountant — turning a once-a-month
// scramble into a per-sale record that's already correctly classified.

import { dbFindById, dbQuery, dbUpdate } from "./db.js";
import { toKes } from "./money.js";
import { getFeatureFlags } from "./sales.js";

export async function buildEtimsInvoice(storeId, sale) {
  const store = await dbFindById("stores", storeId);
  const flags = getFeatureFlags(store);
  const items = await dbQuery("sale_items", { sale_id: sale.id });

  const lineItems = [];
  for (const item of items) {
    const variant = await dbFindById("product_variants", item.variant_id);
    const product = variant ? await dbFindById("products", variant.product_id) : null;
    const taxType = item.tax_type || "standard";
    lineItems.push({
      itemName: `${product?.name ?? "Item"} — ${variant?.variant_label ?? ""}`,
      quantity: item.quantity,
      unitPrice: toKes(item.unit_price_cents),
      taxType,
      taxRate: taxType === "standard" ? sale.vat_rate_pct ?? 0 : 0,
      totalAmount: toKes(item.line_total_cents),
    });
  }

  return {
    invoiceNumber: sale.receipt_number || sale.id,
    traderSystemInvoiceNumber: sale.id,
    invoiceDate: sale.created_at,
    kraPin: flags.kraPin || null,
    totalTaxableAmount: toKes(sale.subtotal_cents - sale.discount_cents),
    totalTaxAmount: toKes(sale.vat_cents + sale.catering_levy_cents),
    totalAmount: toKes(sale.total_cents),
    paymentMethod: resolvePaymentMethodLabel(sale),
    items: lineItems,
  };
}

function resolvePaymentMethodLabel(sale) {
  const methods = [
    sale.cash_tendered_cents > 0 && "CASH",
    sale.mpesa_tendered_cents > 0 && "MPESA",
    sale.card_tendered_cents > 0 && "CARD",
  ].filter(Boolean);
  return methods.length > 1 ? "MIXED" : methods[0] || "CASH";
}

/** Every sale still staged (not yet marked submitted) for this store. */
export async function getPendingEtimsInvoices(storeId) {
  const sales = await dbQuery("sales", { store_id: storeId, etims_status: "pending" });
  return sales.filter((s) => s.status === "completed").sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
}

/** Manual acknowledgement that an invoice has been handed to your approved eTIMS submission path. */
export async function markEtimsSubmitted(saleId) {
  await dbUpdate("sales", saleId, { etims_status: "submitted", updated_at: new Date().toISOString() });
}
