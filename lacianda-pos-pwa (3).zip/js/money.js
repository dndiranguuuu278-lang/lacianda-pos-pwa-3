// js/money.js — integer-cents math, never floats.

// Defaults used only until the shop sets its own rates in Settings > Billing.
export const DEFAULT_VAT_RATE_PCT = 16;
export const DEFAULT_CATERING_LEVY_RATE_PCT = 2.5;

export const toCents = (kes) => Math.round(Number(kes || 0) * 100);
export const toKes = (cents) => cents / 100;

export const formatKes = (cents) =>
  "KES " + toKes(cents).toLocaleString("en-KE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Generic percentage tax calculator — used for both VAT and catering levy, whatever rate the shop has configured (or 0 if disabled). */
export function calcTax(taxableCents, ratePct) {
  return Math.round(taxableCents * (Number(ratePct) / 100));
}

/**
 * KRA eTIMS tax classification. A product's tax_type determines whether
 * VAT actually applies to its line, independent of the shop's overall
 * VAT on/off toggle — a zero-rated or exempt item never carries VAT even
 * if the shop charges VAT on everything else (this is what "correct tax
 * type per item" means for eTIMS compliance).
 */
export const TAX_TYPES = {
  standard: { label: "Standard (VAT applies)", appliesVat: true },
  zero_rated: { label: "Zero-rated (0% VAT)", appliesVat: false },
  exempt: { label: "Exempt (no VAT)", appliesVat: false },
};

export function taxTypeLabel(taxType) {
  return TAX_TYPES[taxType]?.label ?? TAX_TYPES.standard.label;
}

/**
 * Single source of truth for sale totals — used by both the live till
 * display and the actual checkout() call, so they can never disagree.
 * Discount is pro-rated across VAT-eligible vs. VAT-exempt lines so a
 * flat KES discount doesn't accidentally over- or under-tax a mixed cart
 * (e.g. beer at standard rate + an exempt item in the same sale).
 *
 * cart: [{ lineTotalCents, taxType }]
 */
export function computeSaleTotals(cart, discountCents, billing) {
  const subtotalCents = cart.reduce((sum, l) => sum + l.lineTotalCents, 0);
  const taxableCents = Math.max(subtotalCents - discountCents, 0);

  const vatEligibleSubtotalCents = cart
    .filter((l) => (TAX_TYPES[l.taxType] ?? TAX_TYPES.standard).appliesVat)
    .reduce((sum, l) => sum + l.lineTotalCents, 0);

  const discountRatio = subtotalCents > 0 ? taxableCents / subtotalCents : 0;
  const vatEligibleTaxableCents = Math.round(vatEligibleSubtotalCents * discountRatio);

  const vatRatePct = billing.vatEnabled ? billing.vatRatePct : 0;
  const cateringLevyRatePct = billing.cateringLevyEnabled ? billing.cateringLevyRatePct : 0;

  const vatCents = calcTax(vatEligibleTaxableCents, vatRatePct);
  const cateringLevyCents = calcTax(taxableCents, cateringLevyRatePct);
  const totalCents = taxableCents + vatCents + cateringLevyCents;

  return { subtotalCents, discountCents, taxableCents, vatCents, vatRatePct, cateringLevyCents, cateringLevyRatePct, totalCents };
}
