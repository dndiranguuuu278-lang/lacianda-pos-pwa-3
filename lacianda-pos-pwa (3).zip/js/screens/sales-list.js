// js/screens/sales-list.js — browse recent sales, reprint receipts, void
// (gated behind a PIN confirmation when the setting requires it).

import { dbQuery, dbFindById } from "../db.js";
import { formatKes } from "../money.js";
import { voidSale, getFeatureFlags } from "../sales.js";
import { requestPinConfirmation } from "../permissions.js";
import { showReceiptModal } from "../receipt.js";

export async function renderSalesListScreen(root, user) {
  async function load() {
    const store = await dbFindById("stores", user.storeId);
    const flags = getFeatureFlags(store);
    let sales = await dbQuery("sales", { store_id: user.storeId });
    sales = sales.sort((a, b) => (a.created_at < b.created_at ? 1 : -1)).slice(0, 100);
    render(sales, flags);
  }

  function render(sales, flags) {
    root.innerHTML = `
      <div class="screen-pad">
        <div class="row-between mb-2">
          <h1 class="text-xl font-bold">Recent sales</h1>
          <button class="btn btn-outline btn-sm" id="refresh-sales">Refresh</button>
        </div>
        <div class="card">
          <div class="card-body" style="padding:0">
            <table class="simple">
              <thead><tr><th>Receipt</th><th>Time</th><th>Total</th><th>Tender</th><th>Status</th><th></th></tr></thead>
              <tbody>
                ${sales.length === 0 ? `<tr><td colspan="6" class="muted" style="padding:20px;text-align:center">No sales yet.</td></tr>` : sales.map((s) => `
                  <tr>
                    <td>${escapeHtml(s.receipt_number || s.id.slice(0, 8))}</td>
                    <td>${new Date(s.created_at).toLocaleString()}</td>
                    <td>${formatKes(s.total_cents)}</td>
                    <td>${tenderSummary(s)}</td>
                    <td>${statusBadge(s.status)}</td>
                    <td class="row" style="gap:6px">
                      <button class="btn btn-sm btn-outline" data-view="${s.id}">View</button>
                      ${s.status === "completed" ? `<button class="btn btn-sm btn-danger" data-void="${s.id}">Void</button>` : ""}
                    </td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    root.querySelector("#refresh-sales").addEventListener("click", load);
    root.querySelectorAll("[data-view]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const sale = await dbFindById("sales", btn.dataset.view);
        await showReceiptModal(user.storeId, sale, { autoPrint: false });
      });
    });
    root.querySelectorAll("[data-void]").forEach((btn) => {
      btn.addEventListener("click", () => handleVoid(btn.dataset.void, flags));
    });
  }

  async function handleVoid(saleId, flags) {
    if (flags.requirePinForVoid) {
      const approver = await requestPinConfirmation(user.storeId, "Confirm voiding this sale");
      if (!approver) return;
    }

    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal" style="width:360px">
        <button class="modal-close" id="void-close">✕</button>
        <h2>Void sale</h2>
        <label class="label">Reason</label>
        <input id="void-reason" class="input mb-2" placeholder="e.g. Rung up by mistake" />
        <label class="row text-sm mb-2"><input type="checkbox" id="void-restock" checked /> Return items to stock</label>
        <div id="void-error" class="text-sm mb-2" style="color:var(--danger)"></div>
        <button class="btn btn-danger btn-block" id="void-confirm">Confirm void</button>
      </div>
    `;
    document.body.appendChild(backdrop);
    backdrop.querySelector("#void-close").addEventListener("click", () => backdrop.remove());
    backdrop.querySelector("#void-confirm").addEventListener("click", async () => {
      const reason = backdrop.querySelector("#void-reason").value.trim();
      const restock = backdrop.querySelector("#void-restock").checked;
      if (!reason) {
        backdrop.querySelector("#void-error").textContent = "Enter a reason for the void.";
        return;
      }
      try {
        await voidSale(user.storeId, saleId, reason, user.id, restock);
        backdrop.remove();
        load();
      } catch (err) {
        backdrop.querySelector("#void-error").textContent = err.message;
      }
    });
  }

  function tenderSummary(s) {
    const parts = [];
    if (s.cash_tendered_cents) parts.push("Cash");
    if (s.mpesa_tendered_cents) {
      const modeLabels = { personal: "Personal", till: "Buy Goods", paybill: "Paybill", pochi: "Pochi" };
      const modeLabel = modeLabels[s.mpesa_mode] ? ` (${modeLabels[s.mpesa_mode]})` : "";
      parts.push(`M-Pesa${modeLabel}`);
    }
    if (s.card_tendered_cents) parts.push("Card");
    return parts.join(" + ") || "—";
  }

  function statusBadge(status) {
    if (status === "voided") return '<span class="badge badge-amber">Voided</span>';
    if (status === "refunded") return '<span class="badge badge-amber">Refunded</span>';
    return '<span class="badge badge-green">Completed</span>';
  }

  await load();
}

function escapeHtml(s) {
  return (s || "").toString().replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
