// js/screens/import.js — CSV bulk import: upload -> map columns -> preview -> upsert.
// No PapaParse/XLSX dependency in this vanilla build, so a small RFC4180-ish
// CSV parser is included below (handles quoted fields and commas within quotes,
// which covers the vast majority of real-world distributor exports; for full
// .xlsx support use the full source drop's React build, which uses SheetJS).

import { dbInsert, dbQuery, dbUpdate, generateId, nowIso } from "../db.js";
import { getOrCreateBrand, getOrCreateCategory, findVariantByBarcode, createProductWithVariants, restockVariant } from "../inventory.js";

const FIELD_LABELS = {
  ignore: "— Don't import —",
  barcode: "Barcode / EAN",
  productName: "Product name",
  brandName: "Brand",
  categoryName: "Category",
  variantLabel: "Variant label (e.g. 750ml)",
  volumeMl: "Volume (ml)",
  costPriceKes: "Buying / supplier cost price (KES)",
  retailPriceKes: "Retail selling price (KES)",
  wholesalePriceKes: "Wholesale selling price (KES)",
  quantityReceived: "Quantity received",
};

const GUESS_PATTERNS = {
  barcode: /barcode|ean|upc/i, productName: /product|item|description/i, brandName: /brand/i,
  categoryName: /categor/i, variantLabel: /pack|size|variant/i, volumeMl: /volume|ml/i,
  costPriceKes: /cost|buying|supplier.*price/i, retailPriceKes: /retail|selling.*price|srp/i,
  wholesalePriceKes: /wholesale/i, quantityReceived: /qty|quantity|units/i,
};

function parseCsv(text) {
  const rows = [];
  let row = [], field = "", inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i], next = text[i + 1];
    if (inQuotes) {
      if (c === '"' && next === '"') { field += '"'; i++; }
      else if (c === '"') inQuotes = false;
      else field += c;
    } else {
      if (c === '"') inQuotes = true;
      else if (c === ",") { row.push(field); field = ""; }
      else if (c === "\n" || c === "\r") {
        if (c === "\r" && next === "\n") i++;
        row.push(field); field = "";
        if (row.some((f) => f.trim() !== "")) rows.push(row);
        row = [];
      } else field += c;
    }
  }
  if (field !== "" || row.length) { row.push(field); rows.push(row); }
  if (rows.length === 0) return { headers: [], data: [] };
  const headers = rows[0].map((h) => h.trim());
  const data = rows.slice(1).map((r) => Object.fromEntries(headers.map((h, i) => [h, (r[i] ?? "").trim()])));
  return { headers, data };
}

function parseNumeric(raw) {
  const cleaned = (raw || "").replace(/[^0-9.\-]/g, "");
  if (!cleaned) return undefined;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : undefined;
}
const NUMERIC_FIELDS = new Set(["volumeMl", "costPriceKes", "retailPriceKes", "wholesalePriceKes", "quantityReceived"]);

function resolveRows(rawRows, mapping) {
  const active = Object.entries(mapping).filter(([, f]) => f !== "ignore");
  return rawRows.map((raw) => {
    const resolved = {};
    for (const [header, field] of active) {
      const value = raw[header]?.trim();
      if (!value) continue;
      if (NUMERIC_FIELDS.has(field)) {
        const n = parseNumeric(value);
        if (n !== undefined) resolved[field] = n;
      } else resolved[field] = value;
    }
    return resolved;
  });
}

function guessMapping(headers) {
  const mapping = {};
  for (const h of headers) {
    const match = Object.entries(GUESS_PATTERNS).find(([, re]) => re.test(h));
    mapping[h] = match?.[0] ?? "ignore";
  }
  return mapping;
}

async function upsertOne(storeId, row, performedBy) {
  if (!row.barcode) return { action: "skipped", reason: "No barcode — cannot match or dedupe safely.", row };
  if (!row.productName) return { action: "skipped", reason: "No product name.", row };

  const existing = await findVariantByBarcode(storeId, row.barcode);
  if (existing) {
    const patch = { updated_at: nowIso() };
    if (row.costPriceKes !== undefined) patch.cost_price_cents = Math.round(row.costPriceKes * 100);
    if (row.retailPriceKes !== undefined) patch.retail_price_cents = Math.round(row.retailPriceKes * 100);
    if (row.wholesalePriceKes !== undefined) patch.wholesale_price_cents = Math.round(row.wholesalePriceKes * 100);
    if (Object.keys(patch).length > 1) await dbUpdate("product_variants", existing.id, patch);
    if (row.quantityReceived > 0) await restockVariant(storeId, existing, row.quantityReceived, performedBy, "import");
    return { action: "updated", row };
  }

  const brand = await getOrCreateBrand(storeId, row.brandName || "Unbranded");
  const category = await getOrCreateCategory(storeId, row.categoryName || "Extras");
  await createProductWithVariants(storeId, {
    name: row.productName, brandName: brand.name, categoryId: category.id,
    variants: [{
      variantLabel: row.variantLabel || (row.volumeMl ? `${row.volumeMl}ml` : "Unit"),
      volumeMl: row.volumeMl, baseUnitsPerVariant: 1, barcode: row.barcode,
      costPriceCents: Math.round((row.costPriceKes ?? 0) * 100),
      retailPriceCents: Math.round((row.retailPriceKes ?? 0) * 100),
      wholesalePriceCents: Math.round((row.wholesalePriceKes ?? row.retailPriceKes ?? 0) * 100),
      initialStockBaseUnits: row.quantityReceived ?? 0,
    }],
  });
  return { action: "created", row };
}

export function renderImportScreen(root, user) {
  let headers = [], rawRows = [], mapping = {};

  root.innerHTML = `
    <div class="screen-pad">
      <h1 class="text-xl font-bold mb-1">Bulk import from distributor spreadsheet</h1>
      <p class="muted text-sm mb-3">Upload a CSV price list. Matching barcodes update stock and prices; new barcodes create products.
        <span class="text-sm">(.xlsx isn't supported in this offline build — export your spreadsheet as CSV first.)</span></p>
      <div id="import-step"></div>
    </div>
  `;
  const stepEl = root.querySelector("#import-step");

  function renderUploadStep() {
    stepEl.innerHTML = `
      <div class="card"><div class="card-header">1. Upload CSV file</div>
        <div class="card-body">
          <input type="file" id="csv-file" accept=".csv" />
          <div id="upload-error" class="text-sm mt-2" style="color:var(--danger)"></div>
        </div>
      </div>
    `;
    stepEl.querySelector("#csv-file").addEventListener("change", async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const text = await file.text();
      const parsed = parseCsv(text);
      if (parsed.data.length === 0) {
        stepEl.querySelector("#upload-error").textContent = "No rows found in this file.";
        return;
      }
      headers = parsed.headers;
      rawRows = parsed.data;
      mapping = guessMapping(headers);
      renderMapStep();
    });
  }

  function renderMapStep() {
    stepEl.innerHTML = `
      <div class="card"><div class="card-header">2. Match columns</div>
        <div class="card-body">
          <div style="overflow-x:auto">
            <table class="simple">
              <thead><tr><th>Spreadsheet column</th><th>Sample value</th><th>Maps to</th></tr></thead>
              <tbody>
                ${headers.map((h) => `
                  <tr>
                    <td class="font-bold">${escapeHtml(h)}</td>
                    <td class="muted">${escapeHtml(rawRows[0]?.[h] || "empty")}</td>
                    <td>
                      <select class="input map-select" data-header="${escapeHtml(h)}">
                        ${Object.entries(FIELD_LABELS).map(([v, label]) => `<option value="${v}" ${mapping[h] === v ? "selected" : ""}>${label}</option>`).join("")}
                      </select>
                    </td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
          <div id="map-warning" class="text-sm mt-2" style="color:var(--warn)"></div>
          <div class="row-between mt-2">
            <button class="btn btn-ghost" id="map-back">Start over</button>
            <button class="btn" id="map-next">Next: preview</button>
          </div>
        </div>
      </div>
    `;
    stepEl.querySelectorAll(".map-select").forEach((sel) => {
      sel.addEventListener("change", () => { mapping[sel.dataset.header] = sel.value; });
    });
    stepEl.querySelector("#map-back").addEventListener("click", renderUploadStep);
    stepEl.querySelector("#map-next").addEventListener("click", () => {
      if (!Object.values(mapping).includes("barcode")) {
        stepEl.querySelector("#map-warning").textContent = 'Map a column to "Barcode / EAN" to continue — it\'s how we match existing products.';
        return;
      }
      renderPreviewStep();
    });
  }

  function renderPreviewStep() {
    const resolved = resolveRows(rawRows.slice(0, 15), mapping);
    stepEl.innerHTML = `
      <div class="card"><div class="card-header">3. Preview — ${rawRows.length} rows</div>
        <div class="card-body">
          <div style="overflow-x:auto">
            <table class="simple">
              <thead><tr><th>Barcode</th><th>Product</th><th>Brand</th><th>Cost</th><th>Retail</th><th>Wholesale</th><th>Qty</th></tr></thead>
              <tbody>
                ${resolved.map((r) => `
                  <tr>
                    <td>${r.barcode ? escapeHtml(r.barcode) : '<span class="badge badge-amber">missing</span>'}</td>
                    <td>${r.productName ? escapeHtml(r.productName) : '<span class="badge badge-amber">missing</span>'}</td>
                    <td>${escapeHtml(r.brandName || "—")}</td>
                    <td>${r.costPriceKes ?? "—"}</td><td>${r.retailPriceKes ?? "—"}</td>
                    <td>${r.wholesalePriceKes ?? "—"}</td><td>${r.quantityReceived ?? "—"}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
          ${rawRows.length > resolved.length ? `<p class="text-sm muted mt-1">Showing first ${resolved.length} of ${rawRows.length}.</p>` : ""}
          <div class="row-between mt-2">
            <button class="btn btn-ghost" id="preview-back">Back to mapping</button>
            <button class="btn" id="preview-import">Import ${rawRows.length} rows</button>
          </div>
        </div>
      </div>
    `;
    stepEl.querySelector("#preview-back").addEventListener("click", renderMapStep);
    stepEl.querySelector("#preview-import").addEventListener("click", runImport);
  }

  async function runImport() {
    stepEl.innerHTML = `<div class="card"><div class="card-body">Importing…</div></div>`;
    const resolved = resolveRows(rawRows, mapping);
    const results = [];
    for (const row of resolved) {
      try { results.push(await upsertOne(user.storeId, row, user.id)); }
      catch (err) { results.push({ action: "skipped", reason: err.message, row }); }
    }
    renderDoneStep(results);
  }

  function renderDoneStep(results) {
    const created = results.filter((r) => r.action === "created").length;
    const updated = results.filter((r) => r.action === "updated").length;
    const skipped = results.filter((r) => r.action === "skipped");

    stepEl.innerHTML = `
      <div class="card"><div class="card-header">Import complete</div>
        <div class="card-body">
          <div class="grid g3 mb-2">
            <div class="card"><div class="card-body" style="text-align:center"><div class="text-xl font-bold" style="color:var(--success)">${created}</div><div class="text-sm muted">Created</div></div></div>
            <div class="card"><div class="card-body" style="text-align:center"><div class="text-xl font-bold" style="color:#2563eb">${updated}</div><div class="text-sm muted">Updated</div></div></div>
            <div class="card"><div class="card-body" style="text-align:center"><div class="text-xl font-bold" style="color:var(--warn)">${skipped.length}</div><div class="text-sm muted">Skipped</div></div></div>
          </div>
          ${skipped.length ? `<div style="max-height:180px;overflow-y:auto;border:1px solid var(--border);border-radius:8px" class="mb-2">
            ${skipped.map((r) => `<div class="text-sm" style="padding:8px 10px;border-bottom:1px solid var(--border)"><b>${escapeHtml(r.row.productName || r.row.barcode || "Unnamed row")}</b> — ${escapeHtml(r.reason)}</div>`).join("")}
          </div>` : ""}
          <button class="btn" id="import-again">Import another file</button>
        </div>
      </div>
    `;
    stepEl.querySelector("#import-again").addEventListener("click", renderUploadStep);
  }

  renderUploadStep();
}

function escapeHtml(s) {
  return (s || "").toString().replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
