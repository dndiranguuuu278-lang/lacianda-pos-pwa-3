// js/screens/settings.js — account, branding/theme, billing (VAT/levy —
// fully editable), M-Pesa payment modes (Personal/Till/Paybill/Pochi +
// optional STK Push), KRA eTIMS staging, receipts/print, till behavior.

import { dbFindById, dbUpdate, dbQuery, nowIso } from "../db.js";
import { hashPin, verifyPin } from "../auth.js";
import { applyTheme } from "../theme.js";
import { getFeatureFlags } from "../sales.js";

const PRESET_COLORS = ["#7c2d12", "#991b1b", "#1e3a8a", "#166534", "#4c1d95", "#0f172a"];

export async function renderSettingsScreen(root, user) {
  const store = await dbFindById("stores", user.storeId);
  let themeColor = store.theme_primary || "#7c2d12";
  let phoneNumber = store.phone_number || "";
  let receiptHeader = store.receipt_header || "";
  let flags = getFeatureFlags(store);

  root.innerHTML = `
    <div class="screen-pad">
      <h1 class="text-xl font-bold mb-2">Settings</h1>

      <div class="card mb-2">
        <div class="card-header">Account</div>
        <div class="card-body stack">
          <div>
            <label class="label">Your phone number</label>
            <input id="phone-number" class="input" value="${escapeAttr(phoneNumber)}" placeholder="07XX XXX XXX" inputmode="tel" />
            <p class="text-sm muted mt-1">Used for M-Pesa (Personal mode) and to recover your PIN.</p>
          </div>
          <button id="change-pin-btn" class="btn btn-outline btn-sm" style="align-self:flex-start">Change PIN</button>
          <div id="change-pin-form" style="display:none" class="stack mt-1">
            <div class="grid g3">
              <div><label class="label">Current PIN</label><input id="cp-current" class="input" type="password" inputmode="numeric" maxlength="4" /></div>
              <div><label class="label">New PIN</label><input id="cp-new" class="input" type="password" inputmode="numeric" maxlength="4" /></div>
              <div><label class="label">Confirm new PIN</label><input id="cp-new2" class="input" type="password" inputmode="numeric" maxlength="4" /></div>
            </div>
            <div id="cp-error" class="text-sm" style="color:var(--danger)"></div>
            <button id="cp-save" class="btn btn-sm" style="align-self:flex-start">Save new PIN</button>
          </div>
        </div>
      </div>

      <div class="card mb-2">
        <div class="card-header">M-Pesa payment modes</div>
        <div class="card-body stack">
          <p class="text-sm muted">Turn on every mode you actually accept — the till shows a picker at checkout when more than one is on.</p>

          <div class="row-between"><span class="text-sm font-bold">Personal number (Send Money)</span>
            <label class="switch"><input type="checkbox" id="mp-personal-enabled" ${flags.mpesaPersonalEnabled ? "checked" : ""} /><span class="slider"></span></label>
          </div>

          <div class="row-between"><span class="text-sm font-bold">Buy Goods (Till number)</span>
            <label class="switch"><input type="checkbox" id="mp-till-enabled" ${flags.mpesaTillEnabled ? "checked" : ""} /><span class="slider"></span></label>
          </div>
          <input id="mp-till-number" class="input" placeholder="Till number" value="${escapeAttr(flags.mpesaTillNumber)}" />

          <div class="row-between"><span class="text-sm font-bold">Paybill</span>
            <label class="switch"><input type="checkbox" id="mp-paybill-enabled" ${flags.mpesaPaybillEnabled ? "checked" : ""} /><span class="slider"></span></label>
          </div>
          <div class="grid g2">
            <input id="mp-paybill-number" class="input" placeholder="Paybill number" value="${escapeAttr(flags.mpesaPaybillNumber)}" />
            <input id="mp-paybill-account" class="input" placeholder="Account number" value="${escapeAttr(flags.mpesaPaybillAccount)}" />
          </div>

          <div class="row-between"><span class="text-sm font-bold">Pochi la Biashara</span>
            <label class="switch"><input type="checkbox" id="mp-pochi-enabled" ${flags.mpesaPochiEnabled ? "checked" : ""} /><span class="slider"></span></label>
          </div>
          <input id="mp-pochi-number" class="input" placeholder="Pochi la Biashara number" value="${escapeAttr(flags.mpesaPochiNumber)}" />

          <div class="row-between mt-1"><span class="text-sm font-bold">STK Push (prompt-to-pay)</span>
            <label class="switch"><input type="checkbox" id="stk-enabled" ${flags.stkPushEnabled ? "checked" : ""} /><span class="slider"></span></label>
          </div>
          <p class="text-sm muted">Requires your own backend server holding Daraja credentials — this app can't call Safaricom directly from the browser. Point this at that server's URL.</p>
          <input id="stk-backend-url" class="input" placeholder="https://your-server.example.com" value="${escapeAttr(flags.stkPushBackendUrl)}" />
        </div>
      </div>

      <div class="card mb-2">
        <div class="card-header">KRA eTIMS</div>
        <div class="card-body stack">
          <p class="text-sm muted">
            Classifies every sale line by tax type and stages a correctly-shaped invoice per sale.
            Actual submission to KRA still needs your approved eTIMS device/middleware — this
            queues the data for that, it doesn't submit on its own. See the eTIMS queue under Reports.
          </p>
          <div class="row-between"><span class="text-sm font-bold">Enable eTIMS staging</span>
            <label class="switch"><input type="checkbox" id="etims-enabled" ${flags.etimsEnabled ? "checked" : ""} /><span class="slider"></span></label>
          </div>
          <div><label class="label">KRA PIN</label><input id="kra-pin" class="input" value="${escapeAttr(flags.kraPin)}" placeholder="P0XXXXXXXXX" /></div>
          <p class="text-sm muted">Set each product's tax type (Standard / Zero-rated / Exempt) via Advanced pricing when adding or editing it.</p>
        </div>
      </div>

      <div class="card mb-2">
        <div class="card-header">Branding & theme</div>
        <div class="card-body stack">
          <div>
            <label class="label">Theme color</label>
            <div class="row" id="swatches"></div>
          </div>
          <div class="row-between">
            <div><span class="text-sm font-bold">Dark mode</span><p class="text-sm muted">Switch the whole app to a dark background.</p></div>
            <label class="switch"><input type="checkbox" id="dark-mode-toggle" ${flags.darkMode ? "checked" : ""} /><span class="slider"></span></label>
          </div>
          <div><label class="label">Receipt header text</label><input id="receipt-header" class="input" value="${escapeAttr(receiptHeader)}" /></div>
        </div>
      </div>

      <div class="card mb-2">
        <div class="card-header">Billing</div>
        <div class="card-body stack">
          <p class="text-sm muted">Turn these off or change the rate if your shop isn't VAT-registered or the rate changes.</p>
          <div class="grid g2">
            <div class="row-between"><span class="text-sm">Charge VAT</span>
              <label class="switch"><input type="checkbox" id="vat-enabled" ${flags.vatEnabled ? "checked" : ""} /><span class="slider"></span></label>
            </div>
            <div><label class="label">VAT rate (%)</label><input id="vat-rate" class="input" type="number" step="0.1" value="${flags.vatRatePct}" /></div>
            <div class="row-between"><span class="text-sm">Charge catering levy</span>
              <label class="switch"><input type="checkbox" id="levy-enabled" ${flags.cateringLevyEnabled ? "checked" : ""} /><span class="slider"></span></label>
            </div>
            <div><label class="label">Catering levy rate (%)</label><input id="levy-rate" class="input" type="number" step="0.1" value="${flags.cateringLevyRatePct}" /></div>
          </div>
        </div>
      </div>

      <div class="card mb-2">
        <div class="card-header">Receipts & printing</div>
        <div class="card-body stack">
          <div class="row-between"><span class="text-sm">Auto-print receipt after checkout</span>
            <label class="switch"><input type="checkbox" id="auto-print" ${flags.autoPrintReceipt ? "checked" : ""} /><span class="slider"></span></label>
          </div>
          <div>
            <label class="label">Receipt/printer paper width</label>
            <select id="receipt-width" class="input">
              <option value="58mm" ${flags.receiptWidth === "58mm" ? "selected" : ""}>58mm (small thermal printer)</option>
              <option value="80mm" ${flags.receiptWidth === "80mm" ? "selected" : ""}>80mm (standard thermal printer)</option>
            </select>
          </div>
        </div>
      </div>

      <div class="card mb-2">
        <div class="card-header">Till behavior</div>
        <div class="card-body stack" id="toggle-list"></div>
      </div>

      <div class="row">
        <button id="save-settings" class="btn">Save settings</button>
        <span id="save-confirm" class="text-sm" style="color:var(--success)"></span>
      </div>
    </div>
  `;

  // --- theme swatches ---
  const swatchesEl = root.querySelector("#swatches");
  function renderSwatches() {
    swatchesEl.innerHTML = PRESET_COLORS.map((c) =>
      `<div class="color-swatch ${themeColor === c ? "selected" : ""}" style="background:${c}" data-color="${c}"></div>`
    ).join("") + `<input type="color" id="custom-color" value="${themeColor}" style="width:30px;height:30px;border:none;border-radius:6px;cursor:pointer" />`;
    swatchesEl.querySelectorAll("[data-color]").forEach((el) => {
      el.addEventListener("click", () => { themeColor = el.dataset.color; renderSwatches(); });
    });
    swatchesEl.querySelector("#custom-color").addEventListener("input", (e) => { themeColor = e.target.value; renderSwatches(); });
  }
  renderSwatches();

  // --- till behavior toggles ---
  const toggleDefs = [
    ["requirePinForVoid", "Require your PIN to void a sale"],
    ["requirePinForDiscount", "Require your PIN to apply a discount"],
    ["allowNegativeStock", "Allow selling below zero stock (oversell)"],
  ];
  const toggleListEl = root.querySelector("#toggle-list");
  toggleListEl.innerHTML = toggleDefs.map(([key, label]) => `
    <div class="row-between">
      <span class="text-sm">${label}</span>
      <label class="switch"><input type="checkbox" data-flag="${key}" ${flags[key] ? "checked" : ""} /><span class="slider"></span></label>
    </div>
  `).join("");
  toggleListEl.querySelectorAll("[data-flag]").forEach((input) => {
    input.addEventListener("change", () => { flags[input.dataset.flag] = input.checked; });
  });

  // --- change PIN ---
  root.querySelector("#change-pin-btn").addEventListener("click", () => {
    const form = root.querySelector("#change-pin-form");
    form.style.display = form.style.display === "none" ? "flex" : "none";
  });
  root.querySelector("#cp-save").addEventListener("click", async () => {
    const errorEl = root.querySelector("#cp-error");
    const current = root.querySelector("#cp-current").value.trim();
    const next = root.querySelector("#cp-new").value.trim();
    const next2 = root.querySelector("#cp-new2").value.trim();

    const account = (await dbQuery("users", { store_id: user.storeId, id: user.id }))[0];
    if (!account || !(await verifyPin(current, account.pin_hash))) {
      errorEl.textContent = "Current PIN is incorrect.";
      return;
    }
    if (!/^\d{4}$/.test(next)) { errorEl.textContent = "New PIN must be exactly 4 digits."; return; }
    if (next !== next2) { errorEl.textContent = "New PINs don't match."; return; }

    await dbUpdate("users", user.id, { pin_hash: await hashPin(next), updated_at: nowIso() });
    errorEl.style.color = "var(--success)";
    errorEl.textContent = "PIN updated.";
    root.querySelector("#cp-current").value = "";
    root.querySelector("#cp-new").value = "";
    root.querySelector("#cp-new2").value = "";
  });

  // --- save everything ---
  root.querySelector("#save-settings").addEventListener("click", async () => {
    phoneNumber = root.querySelector("#phone-number").value.trim();
    receiptHeader = root.querySelector("#receipt-header").value;

    flags.darkMode = root.querySelector("#dark-mode-toggle").checked;
    flags.vatEnabled = root.querySelector("#vat-enabled").checked;
    flags.vatRatePct = Number(root.querySelector("#vat-rate").value) || 0;
    flags.cateringLevyEnabled = root.querySelector("#levy-enabled").checked;
    flags.cateringLevyRatePct = Number(root.querySelector("#levy-rate").value) || 0;
    flags.autoPrintReceipt = root.querySelector("#auto-print").checked;
    flags.receiptWidth = root.querySelector("#receipt-width").value;

    flags.mpesaPersonalEnabled = root.querySelector("#mp-personal-enabled").checked;
    flags.mpesaTillEnabled = root.querySelector("#mp-till-enabled").checked;
    flags.mpesaTillNumber = root.querySelector("#mp-till-number").value.trim();
    flags.mpesaPaybillEnabled = root.querySelector("#mp-paybill-enabled").checked;
    flags.mpesaPaybillNumber = root.querySelector("#mp-paybill-number").value.trim();
    flags.mpesaPaybillAccount = root.querySelector("#mp-paybill-account").value.trim();
    flags.mpesaPochiEnabled = root.querySelector("#mp-pochi-enabled").checked;
    flags.mpesaPochiNumber = root.querySelector("#mp-pochi-number").value.trim();
    flags.stkPushEnabled = root.querySelector("#stk-enabled").checked;
    flags.stkPushBackendUrl = root.querySelector("#stk-backend-url").value.trim();

    flags.etimsEnabled = root.querySelector("#etims-enabled").checked;
    flags.kraPin = root.querySelector("#kra-pin").value.trim();

    await dbUpdate("stores", user.storeId, {
      theme_primary: themeColor, phone_number: phoneNumber, receipt_header: receiptHeader,
      feature_flags: JSON.stringify(flags), updated_at: nowIso(),
    });

    applyTheme(themeColor, flags.darkMode);

    const confirmEl = root.querySelector("#save-confirm");
    confirmEl.textContent = "Saved.";
    setTimeout(() => (confirmEl.textContent = ""), 2000);
  });
}

function escapeAttr(s) {
  return (s || "").toString().replace(/"/g, "&quot;");
}
