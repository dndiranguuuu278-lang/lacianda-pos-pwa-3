// js/screens/inventory-list.js — browse the full catalog, edit prices/
// pricing tiers/tax type/reorder level, deactivate discontinued items.
// Complements inventory-form.js (which stays focused on adding new products).

import { dbQuery, dbUpdate, nowIso } from "../db.js";
import { formatKes, TAX_TYPES, taxTypeLabel } from "../money.js";
import { listCategories, getPricingTiers } from "../inventory.js";

export async function renderInventoryListScreen(root, user) {
  const categories = await listCategories(user.storeId);
  const categoryNameById = Object.fromEntries(categories.map((c) => [c.id, c.name]));

  async function load() {
    const products = await dbQuery("products", { store_id: user.storeId });
    const stockRows = await dbQuery("inventory_stock", { store_id: user.storeId });
    const stockByProduct = Object.fromEntries(stockRows.map((s) => [s.product_id, s.quantity_on_hand]));

    const rows = [];
    for (const p of products) {
      const variants = await dbQuery("product_variants", { product_id: p.id });
      for (const v of variants) {
        rows.push({ product: p, variant: v, stock: stockByProduct[p.id] ?? 0 });
      }
    }
    render(rows);
  }

  function render(rows) {
    root.innerHTML = `
      <div class="screen-pad" style="max-width:1150px">
        <div class="row-between mb-2">
          <h1 class="text-xl font-bold">Inventory</h1>
          <input id="inv-search" class="input" placeholder="Search products…" style="width:260px" />
        </div>
        <div class="card">
          <div class="card-body" style="padding:0;overflow-x:auto">
            <table class="simple" id="inv-table">
              <thead>
                <tr><th>Product</th><th>Variant</th><th>Category</th><th>Stock</th><th>Pricing</th><th>Tax type</th><th>Active</th><th></th></tr>
              </thead>
              <tbody>
                ${rows.map((r) => rowHtml(r)).join("")}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    const searchInput = root.querySelector("#inv-search");
    searchInput.addEventListener("input", () => {
      const q = searchInput.value.trim().toLowerCase();
      root.querySelectorAll("#inv-table tbody tr").forEach((tr) => {
        tr.style.display = tr.dataset.searchtext.includes(q) ? "" : "none";
      });
    });

    root.querySelectorAll("[data-edit]").forEach((btn) => btn.addEventListener("click", () => openEditModal(btn.dataset.edit, rows)));
    root.querySelectorAll("[data-toggle-active]").forEach((cb) => {
      cb.addEventListener("change", async () => {
        await dbUpdate("product_variants", cb.dataset.toggleActive, { is_active: cb.checked, updated_at: nowIso() });
      });
    });
  }

  function rowHtml(r) {
    const lowStock = r.stock <= (r.variant.reorder_level || 0);
    const tiers = getPricingTiers(r.variant);
    const pricingSummary = tiers.length > 1
      ? tiers.map((t) => `${t.minQty === 1 ? "Base" : `${t.minQty}+`}: ${formatKes(t.priceCents)}`).join(" · ")
      : formatKes(r.variant.retail_price_cents);

    return `
      <tr data-searchtext="${escapeAttr((r.product.name + " " + r.variant.variant_label + " " + (r.variant.barcode || "")).toLowerCase())}">
        <td>${escapeHtml(r.product.name)}</td>
        <td>${escapeHtml(r.variant.variant_label)}</td>
        <td>${escapeHtml(categoryNameById[r.product.category_id] || "—")}</td>
        <td>${lowStock ? `<span class="badge badge-amber">${r.stock}</span>` : r.stock}</td>
        <td class="text-sm">${pricingSummary}</td>
        <td class="text-sm">${escapeHtml(taxTypeLabel(r.variant.tax_type))}</td>
        <td><label class="switch"><input type="checkbox" data-toggle-active="${r.variant.id}" ${r.variant.is_active !== false ? "checked" : ""} /><span class="slider"></span></label></td>
        <td><button class="btn btn-sm btn-outline" data-edit="${r.variant.id}">Edit</button></td>
      </tr>
    `;
  }

  function tierRowHtml(tier) {
    return `
      <div class="row tier-row" style="gap:6px;align-items:center">
        <span class="text-sm muted" style="width:70px">Qty ≥</span>
        <input class="input tier-qty" type="number" min="1" value="${tier.minQty}" style="width:70px" ${tier.minQty === 1 ? "disabled" : ""} />
        <span class="text-sm muted">price</span>
        <input class="input tier-price" type="number" value="${tier.priceCents / 100}" style="width:100px" />
        ${tier.minQty !== 1 ? `<button type="button" class="btn-ghost btn-sm remove-tier">✕</button>` : `<span style="width:32px"></span>`}
      </div>
    `;
  }

  function openEditModal(variantId, rows) {
    const r = rows.find((r) => r.variant.id === variantId);
    if (!r) return;
    const tiers = getPricingTiers(r.variant);

    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal">
        <button class="modal-close" id="edit-close">✕</button>
        <h2>${escapeHtml(r.product.name)} — ${escapeHtml(r.variant.variant_label)}</h2>
        <div class="grid g2 mb-2">
          <div><label class="label">Cost price (KES)</label><input id="edit-cost" class="input" type="number" value="${r.variant.cost_price_cents / 100}" /></div>
          <div><label class="label">Reorder level</label><input id="edit-reorder" class="input" type="number" value="${r.variant.reorder_level ?? 0}" /></div>
          <div><label class="label">Barcode</label><input id="edit-barcode" class="input" value="${escapeAttr(r.variant.barcode || "")}" /></div>
          <div>
            <label class="label">Tax type (eTIMS)</label>
            <select id="edit-taxtype" class="input">
              ${Object.entries(TAX_TYPES).map(([key, t]) => `<option value="${key}" ${r.variant.tax_type === key ? "selected" : ""}>${t.label}</option>`).join("")}
            </select>
          </div>
        </div>
        <div class="mb-2">
          <label class="label">Pricing tiers</label>
          <div id="edit-tiers-container" class="stack"></div>
          <button type="button" class="btn btn-sm btn-outline mt-1" id="edit-add-tier">+ Add price tier</button>
        </div>
        <div class="text-sm muted mb-2">Current stock: ${r.stock} base units. Adjust stock counts via Bulk Import (restock) rather than here, so every change stays in the audit trail.</div>
        <div id="edit-error" class="text-sm mb-2" style="color:var(--danger)"></div>
        <button class="btn" id="edit-save">Save changes</button>
      </div>
    `;
    document.body.appendChild(backdrop);

    const tiersContainer = backdrop.querySelector("#edit-tiers-container");
    function appendTierRow(tier) {
      const wrap = document.createElement("div");
      wrap.innerHTML = tierRowHtml(tier);
      const row = wrap.firstElementChild;
      row.querySelector(".remove-tier")?.addEventListener("click", () => row.remove());
      tiersContainer.appendChild(row);
    }
    tiers.forEach(appendTierRow);

    backdrop.querySelector("#edit-add-tier").addEventListener("click", () => appendTierRow({ minQty: 2, priceCents: r.variant.retail_price_cents }));
    backdrop.querySelector("#edit-close").addEventListener("click", () => backdrop.remove());

    backdrop.querySelector("#edit-save").addEventListener("click", async () => {
      const newTiers = [];
      tiersContainer.querySelectorAll(".tier-row").forEach((row) => {
        const minQty = Number(row.querySelector(".tier-qty").value) || 1;
        const priceKes = Number(row.querySelector(".tier-price").value) || 0;
        if (priceKes > 0) newTiers.push({ minQty, priceCents: Math.round(priceKes * 100) });
      });
      newTiers.sort((a, b) => a.minQty - b.minQty);
      const baseTier = newTiers.find((t) => t.minQty === 1) || { minQty: 1, priceCents: r.variant.retail_price_cents };

      await dbUpdate("product_variants", variantId, {
        cost_price_cents: Math.round((Number(backdrop.querySelector("#edit-cost").value) || 0) * 100),
        retail_price_cents: baseTier.priceCents,
        pricing_tiers: newTiers.length > 1 ? newTiers : null,
        tax_type: backdrop.querySelector("#edit-taxtype").value,
        reorder_level: Number(backdrop.querySelector("#edit-reorder").value) || 0,
        barcode: backdrop.querySelector("#edit-barcode").value.trim() || null,
        updated_at: nowIso(),
      });
      backdrop.remove();
      load();
    });
  }

  await load();
}

function escapeHtml(s) {
  return (s || "").toString().replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function escapeAttr(s) {
  return escapeHtml(s);
}
