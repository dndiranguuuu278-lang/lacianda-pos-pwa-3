// js/screens/till.js — the main POS screen: product grid + cart + checkout.
// Checkout is non-blocking: confirming a sale prints (if auto-print is on)
// and returns straight to a fresh till with a toast, not a modal to dismiss.
// M-Pesa supports Personal/Till/Paybill/Pochi la Biashara — whichever
// modes are enabled in Settings — plus an optional STK Push trigger.

import { listProductsWithVariants, listCategories, resolveUnitPrice, getLowStockProducts } from "../inventory.js";
import { checkout, getFeatureFlags } from "../sales.js";
import { computeSaleTotals, formatKes } from "../money.js";
import { printReceipt, showReceiptModal } from "../receipt.js";
import { requestPinConfirmation } from "../permissions.js";
import { dbFindById } from "../db.js";
import { tillState, resetTillState } from "../till-state.js";
import { initiateStkPush, waitForStkResult, StkPushNotConfiguredError } from "../stk-push.js";

// Registered ONCE at module load (not per screen-render) — looks up the
// search bar by id fresh on every focusout, so it's naturally a no-op
// when the Till screen isn't the one currently mounted, and never
// accumulates duplicate document-level listeners across navigation.
document.addEventListener("focusout", () => {
  setTimeout(() => {
    const searchBar = document.getElementById("search-bar");
    if (!searchBar) return;
    const active = document.activeElement;
    const isTextField = active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA");
    const modalOpen = document.querySelector(".modal-backdrop");
    if (!isTextField && !modalOpen) searchBar.focus();
  }, 60);
});

export async function renderTillScreen(root, user) {
  const products = await listProductsWithVariants(user.storeId);
  const categories = await listCategories(user.storeId);
  const store = await dbFindById("stores", user.storeId);
  const flags = getFeatureFlags(store);
  const lowStock = await getLowStockProducts(user.storeId);
  const lowStockProductNames = new Set(lowStock.map((i) => i.productName));

  const mpesaModes = [
    flags.mpesaPersonalEnabled && { key: "personal", label: "Personal", instruction: `Send to ${store?.phone_number || "(not set)"}` },
    flags.mpesaTillEnabled && { key: "till", label: "Buy Goods", instruction: `Till number ${flags.mpesaTillNumber || "(not set)"}` },
    flags.mpesaPaybillEnabled && { key: "paybill", label: "Paybill", instruction: `Paybill ${flags.mpesaPaybillNumber || "(not set)"}, Account ${flags.mpesaPaybillAccount || "(not set)"}` },
    flags.mpesaPochiEnabled && { key: "pochi", label: "Pochi la Biashara", instruction: `Send to ${flags.mpesaPochiNumber || "(not set)"}` },
  ].filter(Boolean);

  let cart = tillState.cart;
  let activeCategory = "all";
  let discountKes = tillState.discountKes;
  let discountPromptOpen = false;
  let selectedMpesaMode = mpesaModes[0]?.key ?? "personal";

  function setCart(next) { cart = next; tillState.cart = next; }
  function setDiscount(next) { discountKes = next; tillState.discountKes = next; }

  root.innerHTML = `
    <div class="till-grid">
      <div class="stack" style="height:100%">
        <h2 class="text-lg font-bold">Current sale</h2>
        <div class="cart-lines" id="cart-lines"></div>
        <div class="totals-box" id="totals-box"></div>
        <button id="checkout-btn" class="btn btn-lg btn-block">Checkout</button>
      </div>
      <div class="stack" style="height:100%">
        <input id="search-bar" class="search-bar" placeholder="Scan barcode or search products…" autocomplete="off" />
        <div class="cat-tabs" id="cat-tabs"></div>
        <div class="product-grid" id="product-grid"></div>
      </div>
    </div>
  `;

  const searchBar = root.querySelector("#search-bar");
  const catTabs = root.querySelector("#cat-tabs");
  const productGrid = root.querySelector("#product-grid");
  const cartLinesEl = root.querySelector("#cart-lines");
  const totalsBoxEl = root.querySelector("#totals-box");

  searchBar.focus();

  // ---------------- category tabs ----------------
  function renderCatTabs() {
    const tabs = [{ id: "all", name: "All" }, ...categories];
    catTabs.innerHTML = tabs
      .map((c) => `<button class="cat-tab ${activeCategory === c.id ? "active" : ""}" data-cat="${c.id}">${escapeHtml(c.name)}</button>`)
      .join("");
    catTabs.querySelectorAll("[data-cat]").forEach((btn) => {
      btn.addEventListener("click", () => { activeCategory = btn.dataset.cat; renderCatTabs(); renderGrid(); });
    });
  }

  // ---------------- product grid ----------------
  function renderGrid() {
    const search = searchBar.value.trim().toLowerCase();
    let list = products;
    if (activeCategory !== "all") list = list.filter((p) => p.category_id === activeCategory);
    if (search) {
      list = list.filter((p) => p.name.toLowerCase().includes(search) || p.variants.some((v) => v.barcode === searchBar.value.trim()));
    }

    const tiles = [];
    for (const p of list) {
      for (const v of p.variants) tiles.push({ p, v });
    }

    productGrid.innerHTML = tiles.length
      ? tiles.map(({ p, v }, i) => `
        <button class="product-tile" data-idx="${i}">
          <div class="pname">${escapeHtml(p.name)}</div>
          <div class="pvariant">${escapeHtml(v.variant_label)} ${lowStockProductNames.has(p.name) ? '<span class="badge badge-amber">low stock</span>' : ""}</div>
          <div class="pprice">${formatKes(v.retail_price_cents)}</div>
        </button>
      `).join("")
      : `<p class="muted text-sm" style="grid-column:1/-1;text-align:center;padding:40px 0">No products match.</p>`;

    productGrid.querySelectorAll("[data-idx]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const { p, v } = tiles[Number(btn.dataset.idx)];
        addToCart(p, v);
      });
    });
  }

  // ---------------- cart logic ----------------
  function addToCart(product, variant, qty = 1) {
    const existing = cart.find((l) => l.variantId === variant.id);
    const newQty = (existing?.quantity ?? 0) + qty;
    const { unitPriceCents, isWholesale, tierLabel } = resolveUnitPrice(variant, newQty);
    const line = {
      variantId: variant.id, productId: product.id, variant,
      label: `${product.name} — ${variant.variant_label}`,
      quantity: newQty, unitPriceCents, isWholesale, tierLabel,
      taxType: variant.tax_type || "standard",
      lineTotalCents: unitPriceCents * newQty,
    };
    setCart(existing ? cart.map((l) => (l.variantId === variant.id ? line : l)) : [...cart, line]);
    renderCart();
    searchBar.value = "";
    searchBar.focus();
  }

  function setQty(variantId, qty) {
    const line = cart.find((l) => l.variantId === variantId);
    if (!line) return;
    if (qty <= 0) { setCart(cart.filter((l) => l.variantId !== variantId)); renderCart(); return; }
    const { unitPriceCents, isWholesale, tierLabel } = resolveUnitPrice(line.variant, qty);
    setCart(cart.map((l) => (l.variantId === variantId ? { ...l, quantity: qty, unitPriceCents, isWholesale, tierLabel, lineTotalCents: unitPriceCents * qty } : l)));
    renderCart();
  }

  function removeLine(variantId) {
    setCart(cart.filter((l) => l.variantId !== variantId));
    renderCart();
  }

  function renderCart() {
    cartLinesEl.innerHTML = cart.length
      ? cart.map((l) => `
        <div class="cart-line">
          <div class="cl-info">
            <div class="cl-name">${escapeHtml(l.label)}</div>
            <div class="cl-price">${formatKes(l.unitPriceCents)} ${l.isWholesale ? `<span class="cl-wholesale">· ${l.tierLabel || "tiered"}</span>` : ""}</div>
          </div>
          <div class="qty-stepper">
            <button data-dec="${l.variantId}">−</button>
            <span>${l.quantity}</span>
            <button data-inc="${l.variantId}">+</button>
          </div>
          <div class="cl-total">${formatKes(l.lineTotalCents)}</div>
          <button class="cl-remove" data-remove="${l.variantId}">✕</button>
        </div>
      `).join("")
      : `<p class="muted text-sm" style="padding:24px;text-align:center">Scan or tap a product to begin.</p>`;

    cartLinesEl.querySelectorAll("[data-inc]").forEach((b) => b.addEventListener("click", () => {
      const l = cart.find((l) => l.variantId === b.dataset.inc); setQty(l.variantId, l.quantity + 1);
    }));
    cartLinesEl.querySelectorAll("[data-dec]").forEach((b) => b.addEventListener("click", () => {
      const l = cart.find((l) => l.variantId === b.dataset.dec); setQty(l.variantId, l.quantity - 1);
    }));
    cartLinesEl.querySelectorAll("[data-remove]").forEach((b) => b.addEventListener("click", () => removeLine(b.dataset.remove)));

    renderTotals();
  }

  function computeTotals() {
    const discountCents = Math.round(discountKes * 100);
    return computeSaleTotals(cart, discountCents, {
      vatEnabled: flags.vatEnabled, vatRatePct: flags.vatRatePct,
      cateringLevyEnabled: flags.cateringLevyEnabled, cateringLevyRatePct: flags.cateringLevyRatePct,
    });
  }

  function renderTotals() {
    const t = computeTotals();
    totalsBoxEl.innerHTML = `
      <div class="trow"><span>Subtotal</span><span>${formatKes(t.subtotalCents)}</span></div>
      <div class="trow"><span>Discount (KES)</span><input id="discount-input" class="input" type="number" min="0" value="${discountKes || ""}" style="width:90px;text-align:right;padding:2px 8px" /></div>
      ${flags.vatEnabled ? `<div class="trow"><span>VAT (${t.vatRatePct}%)</span><span>${formatKes(t.vatCents)}</span></div>` : ""}
      ${flags.cateringLevyEnabled ? `<div class="trow"><span>Catering levy (${t.cateringLevyRatePct}%)</span><span>${formatKes(t.cateringLevyCents)}</span></div>` : ""}
      <div class="trow total"><span>Total due</span><span>${formatKes(t.totalCents)}</span></div>
    `;
    const discountInput = root.querySelector("#discount-input");
    discountInput.addEventListener("change", async (e) => {
      // Guard against re-entrancy: showing the PIN-confirmation modal
      // steals focus from this input, which can trigger a second native
      // 'change' event on blur while the first call is still awaiting.
      if (discountPromptOpen) return;
      discountPromptOpen = true;
      try {
        const requested = Number(e.target.value) || 0;
        if (requested > 0 && flags.requirePinForDiscount) {
          const approver = await requestPinConfirmation(user.storeId, `Confirm a discount of ${formatKes(Math.round(requested * 100))}`);
          if (!approver) { e.target.value = discountKes || ""; return; }
        }
        setDiscount(requested);
        renderTotals();
      } finally {
        discountPromptOpen = false;
      }
    });
    root.querySelector("#checkout-btn").textContent = `Checkout — ${formatKes(t.totalCents)}`;
    root.querySelector("#checkout-btn").disabled = cart.length === 0;
  }

  // ---------------- search / scan handling ----------------
  searchBar.addEventListener("input", renderGrid);
  searchBar.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    const scanned = searchBar.value.trim();
    if (!scanned) return;
    for (const p of products) {
      const v = p.variants.find((v) => v.barcode === scanned);
      if (v) { addToCart(p, v); return; }
    }
  });

  root.querySelector("#checkout-btn").addEventListener("click", () => {
    if (cart.length === 0) return;
    openCheckoutModal();
  });

  // ---------------- checkout modal ----------------
  function openCheckoutModal() {
    const t = computeTotals();
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal">
        <button class="modal-close" id="co-close">✕</button>
        <h2>Checkout — ${formatKes(t.totalCents)} due</h2>
        <div class="grid g3 mb-2">
          <div><label class="label">Cash (KES)</label><input id="co-cash" class="input" type="number" min="0" placeholder="0" /></div>
          <div><label class="label">M-Pesa (KES)</label><input id="co-mpesa" class="input" type="number" min="0" placeholder="0" /></div>
          <div><label class="label">Card (KES)</label><input id="co-card" class="input" type="number" min="0" placeholder="0" /></div>
        </div>
        <div id="co-mpesa-block" style="display:none" class="card mb-2">
          <div class="card-body stack">
            ${mpesaModes.length > 1 ? `
              <div class="row" id="mpesa-mode-tabs" style="flex-wrap:wrap">
                ${mpesaModes.map((m) => `<button type="button" class="cat-tab ${m.key === selectedMpesaMode ? "active" : ""}" data-mode="${m.key}">${m.label}</button>`).join("")}
              </div>
            ` : ""}
            <p class="text-sm" id="mpesa-instruction">${mpesaModes.length ? escapeHtml(mpesaModes.find((m) => m.key === selectedMpesaMode)?.instruction || "") : '<span style="color:var(--warn)">No M-Pesa mode configured — add one in Settings.</span>'}</p>
            ${flags.stkPushEnabled ? `
              <div class="row" style="gap:8px">
                <input id="co-stk-phone" class="input" placeholder="Customer phone 07XX..." style="flex:1" />
                <button type="button" id="co-stk-send" class="btn btn-sm">Send STK Push</button>
              </div>
              <div id="co-stk-status" class="text-sm muted"></div>
            ` : ""}
            <label class="label">Note (optional)</label>
            <input id="co-mpesa-note" class="input" placeholder="e.g. customer's name" />
          </div>
        </div>
        <div class="row-between" style="background:var(--muted-bg);padding:10px 12px;border-radius:8px;margin-bottom:8px">
          <span class="text-sm">Tendered</span><span id="co-tendered" class="font-bold">${formatKes(0)}</span>
        </div>
        <div id="co-error" class="text-sm mb-2" style="color:var(--danger)"></div>
        <div class="row" style="justify-content:flex-end;gap:8px">
          <button id="co-cancel" class="btn btn-ghost">Cancel</button>
          <button id="co-confirm" class="btn">Confirm sale</button>
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);

    const cashInput = backdrop.querySelector("#co-cash");
    const mpesaInput = backdrop.querySelector("#co-mpesa");
    const cardInput = backdrop.querySelector("#co-card");
    const mpesaBlock = backdrop.querySelector("#co-mpesa-block");
    const mpesaNoteInput = backdrop.querySelector("#co-mpesa-note");
    const tenderedEl = backdrop.querySelector("#co-tendered");
    const errorEl = backdrop.querySelector("#co-error");
    let stkVerified = false;

    function updateTendered() {
      const cash = Math.round((Number(cashInput.value) || 0) * 100);
      const mpesa = Math.round((Number(mpesaInput.value) || 0) * 100);
      const card = Math.round((Number(cardInput.value) || 0) * 100);
      tenderedEl.textContent = formatKes(cash + mpesa + card);
      mpesaBlock.style.display = mpesa > 0 ? "block" : "none";
    }
    [cashInput, mpesaInput, cardInput].forEach((el) => el.addEventListener("input", updateTendered));

    backdrop.querySelectorAll("[data-mode]").forEach((btn) => {
      btn.addEventListener("click", () => {
        selectedMpesaMode = btn.dataset.mode;
        backdrop.querySelectorAll("[data-mode]").forEach((b) => b.classList.toggle("active", b.dataset.mode === selectedMpesaMode));
        backdrop.querySelector("#mpesa-instruction").textContent = mpesaModes.find((m) => m.key === selectedMpesaMode)?.instruction || "";
      });
    });

    const stkSendBtn = backdrop.querySelector("#co-stk-send");
    if (stkSendBtn) {
      stkSendBtn.addEventListener("click", async () => {
        const phone = backdrop.querySelector("#co-stk-phone").value.trim();
        const statusEl = backdrop.querySelector("#co-stk-status");
        if (!phone) { statusEl.textContent = "Enter the customer's phone number first."; statusEl.style.color = "var(--danger)"; return; }
        const amountKes = Number(mpesaInput.value) || 0;
        if (amountKes <= 0) { statusEl.textContent = "Enter the M-Pesa amount first."; statusEl.style.color = "var(--danger)"; return; }

        statusEl.style.color = "var(--muted-foreground)";
        statusEl.textContent = "Sending prompt to customer's phone…";
        stkSendBtn.disabled = true;
        try {
          const { checkoutRequestId } = await initiateStkPush(flags.stkPushBackendUrl, { phoneNumber: phone, amountKes, saleId: crypto.randomUUID() });
          const result = await waitForStkResult(flags.stkPushBackendUrl, checkoutRequestId, {
            onTick: (r) => { if (r.status === "pending") statusEl.textContent = "Waiting for customer to enter PIN…"; },
          });
          if (result.status === "success") {
            stkVerified = true;
            statusEl.style.color = "var(--success)";
            statusEl.textContent = `Confirmed${result.mpesaCode ? " — " + result.mpesaCode : ""}.`;
          } else {
            statusEl.style.color = "var(--warn)";
            statusEl.textContent = "Prompt wasn't completed. You can still record the payment manually below.";
          }
        } catch (err) {
          statusEl.style.color = "var(--danger)";
          statusEl.textContent = err instanceof StkPushNotConfiguredError ? err.message : (err.message || "STK Push failed.");
        } finally {
          stkSendBtn.disabled = false;
        }
      });
    }

    function close() { backdrop.remove(); searchBar.focus(); }
    backdrop.querySelector("#co-close").addEventListener("click", close);
    backdrop.querySelector("#co-cancel").addEventListener("click", close);

    backdrop.querySelector("#co-confirm").addEventListener("click", async () => {
      errorEl.textContent = "";
      const cashCents = Math.round((Number(cashInput.value) || 0) * 100);
      const mpesaCents = Math.round((Number(mpesaInput.value) || 0) * 100);
      const cardCents = Math.round((Number(cardInput.value) || 0) * 100);
      const mpesaNote = mpesaNoteInput.value.trim();

      try {
        const result = await checkout(
          user.storeId, user.id, user.activeShift?.id ?? null, cart,
          Math.round(discountKes * 100),
          { cashCents, mpesaCents, cardCents, mpesaMode: selectedMpesaMode, mpesaNote, mpesaStkVerified: stkVerified },
          { vatEnabled: flags.vatEnabled, vatRatePct: flags.vatRatePct, cateringLevyEnabled: flags.cateringLevyEnabled, cateringLevyRatePct: flags.cateringLevyRatePct }
        );
        close();
        setCart([]);
        setDiscount(0);
        renderCart();

        if (flags.autoPrintReceipt) {
          printReceipt(user.storeId, result.sale).catch(() => { /* popup blocked — receipt is still on the Sales list */ });
        }
        showToast(`Sale complete — receipt ${result.sale.receipt_number}`, () => showReceiptModal(user.storeId, result.sale, { autoPrint: false }));
        renderGrid();
      } catch (err) {
        errorEl.textContent = err.message || "Checkout failed.";
      }
    });
  }

  function showToast(message, onView) {
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.innerHTML = `<span>${escapeHtml(message)}</span> ${onView ? '<button id="toast-view" style="margin-left:10px;background:none;border:1px solid rgba(255,255,255,.5);color:white;border-radius:6px;padding:2px 8px;font-size:12px">View</button>' : ""}`;
    document.body.appendChild(toast);
    if (onView) toast.querySelector("#toast-view").addEventListener("click", () => { onView(); toast.remove(); });
    setTimeout(() => toast.remove(), 4500);
  }

  renderCatTabs();
  renderGrid();
  renderCart();
}

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
