// js/screens/login.js — single-account setup, PIN login, and phone-based
// PIN recovery. There is exactly one account per shop (the owner) — no
// staff picker, no user list to search through.
//
// HONEST LIMITATION: this is a static, offline-first app with no backend,
// so there is no real SMS gateway to actually text a code to the phone
// number on file. The "verification code" flow below generates a code
// locally and displays it directly (plus an optional link that opens your
// phone's own SMS app with the code pre-filled, if you want to text it to
// yourself as a record). Real SMS delivery to a *different* device would
// require a server-side SMS provider (e.g. Africa's Talking, Twilio),
// which the full networked version of this system could add.

import { dbInsert, dbUpdate, dbQuery, dbAll, generateId, nowIso } from "../db.js";
import { hashPin, verifyPin } from "../auth.js";
import { seedCatalogIfEmpty } from "../inventory.js";

const PIN_LENGTH = 4;
const RECOVERY_CODE_TTL_MS = 10 * 60 * 1000; // 10 minutes

export async function renderLoginScreen(root, onLoggedIn) {
  const stores = await dbAll("stores");
  if (stores.length === 0) {
    renderFirstRunSetup(root, onLoggedIn);
  } else {
    renderPinPad(root, stores[0], onLoggedIn);
  }
}

// ---------------- First run: create the one account ----------------

function renderFirstRunSetup(root, onLoggedIn) {
  root.innerHTML = `
    <div class="pin-screen">
      <h1 class="text-xl font-bold" style="color:var(--primary)">Welcome to Lacianda POS</h1>
      <p class="muted text-sm">Let's set up your account. This only happens once.</p>
      <div class="card" style="width:360px">
        <div class="card-body stack">
          <div>
            <label class="label">Shop name</label>
            <input id="su-shopname" class="input" value="Lacianda Wines and Spirits" />
          </div>
          <div>
            <label class="label">Your name</label>
            <input id="su-ownername" class="input" placeholder="e.g. James Mwangi" />
          </div>
          <div>
            <label class="label">Your phone number</label>
            <input id="su-phone" class="input" placeholder="07XX XXX XXX" inputmode="tel" />
            <p class="text-sm muted mt-1">Used for M-Pesa payments at checkout and to recover your PIN if you forget it.</p>
          </div>
          <div>
            <label class="label">Choose a ${PIN_LENGTH}-digit PIN</label>
            <input id="su-pin" class="input" type="password" inputmode="numeric" maxlength="${PIN_LENGTH}" placeholder="••••" />
          </div>
          <div>
            <label class="label">Confirm PIN</label>
            <input id="su-pin2" class="input" type="password" inputmode="numeric" maxlength="${PIN_LENGTH}" placeholder="••••" />
          </div>
          <div id="su-error" class="text-sm" style="color:var(--danger)"></div>
          <button id="su-submit" class="btn btn-block">Create account & sign in</button>
        </div>
      </div>
    </div>
  `;

  root.querySelector("#su-submit").addEventListener("click", async () => {
    const shopName = root.querySelector("#su-shopname").value.trim() || "Lacianda Wines and Spirits";
    const ownerName = root.querySelector("#su-ownername").value.trim();
    const phone = root.querySelector("#su-phone").value.trim();
    const pin = root.querySelector("#su-pin").value.trim();
    const pin2 = root.querySelector("#su-pin2").value.trim();
    const errorEl = root.querySelector("#su-error");

    if (!ownerName) return (errorEl.textContent = "Enter your name.");
    if (!phone) return (errorEl.textContent = "Enter your phone number — it's needed for M-Pesa and PIN recovery.");
    if (!/^\d{4}$/.test(pin)) return (errorEl.textContent = `PIN must be exactly ${PIN_LENGTH} digits.`);
    if (pin !== pin2) return (errorEl.textContent = "PINs don't match.");

    const storeId = generateId();
    await dbInsert("stores", {
      id: storeId, name: shopName, phone_number: phone,
      receipt_header: `${shopName}, Thank You for Your Business!`,
      theme_primary: "#7c2d12",
      feature_flags: JSON.stringify({
        requirePinForVoid: true, requirePinForDiscount: false, allowNegativeStock: false,
        autoPrintReceipt: true, darkMode: false,
        vatEnabled: true, vatRatePct: 16, cateringLevyEnabled: true, cateringLevyRatePct: 2.5,
        receiptWidth: "58mm",
      }),
      updated_at: nowIso(),
    });

    const userId = generateId();
    await dbInsert("users", {
      id: userId, store_id: storeId, full_name: ownerName, role: "owner",
      pin_hash: await hashPin(pin), is_active: true, updated_at: nowIso(),
    });

    await seedCatalogIfEmpty(storeId);

    const shift = {
      id: generateId(), store_id: storeId, cashier_id: userId, opening_float_cents: 0,
      opened_at: nowIso(), closed_at: null, updated_at: nowIso(),
    };
    await dbInsert("shifts", shift);

    onLoggedIn({ id: userId, fullName: ownerName, role: "owner", storeId, activeShift: shift });
  });
}

// ---------------- Returning: PIN pad ----------------

function renderPinPad(root, store, onLoggedIn) {
  let pin = "";
  let attempts = 0;
  let lockedUntil = 0;

  root.innerHTML = `
    <div class="pin-screen">
      <h1 class="text-xl font-bold" style="color:var(--primary)">${escapeHtml(store.name)}</h1>
      <p class="muted text-sm">Enter your PIN to sign in</p>
      <div class="pin-dots" id="pin-dots"></div>
      <div id="pin-error" class="text-sm" style="color:var(--danger)"></div>
      <div id="pin-checking" class="text-sm muted"></div>
      <div class="pin-pad" id="pin-pad"></div>
      <button id="forgot-pin" class="btn-ghost text-sm" style="text-decoration:underline">Forgot PIN?</button>
    </div>
  `;

  const dotsEl = root.querySelector("#pin-dots");
  const errorEl = root.querySelector("#pin-error");
  const checkingEl = root.querySelector("#pin-checking");
  const padEl = root.querySelector("#pin-pad");

  function renderDots() {
    dotsEl.innerHTML = Array.from({ length: PIN_LENGTH })
      .map((_, i) => `<div class="pin-dot ${i < pin.length ? "filled" : ""}"></div>`)
      .join("");
  }

  function renderPad() {
    const locked = Date.now() < lockedUntil;
    const keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫"];
    padEl.innerHTML = keys
      .map((k) => (k === "" ? "<div></div>" : `<button class="pin-key" data-key="${k}" ${locked ? "disabled" : ""}>${k}</button>`))
      .join("");
    padEl.querySelectorAll("[data-key]").forEach((btn) => {
      btn.addEventListener("click", () => handleKey(btn.dataset.key));
    });
  }

  async function handleKey(key) {
    if (Date.now() < lockedUntil) return;
    if (key === "⌫") {
      pin = pin.slice(0, -1);
      errorEl.textContent = "";
      renderDots();
      return;
    }
    pin = (pin + key).slice(0, PIN_LENGTH);
    renderDots();
    if (pin.length === PIN_LENGTH) await attemptLogin();
  }

  async function attemptLogin() {
    checkingEl.textContent = "Checking…";
    const users = await dbQuery("users", { store_id: store.id, is_active: true });
    let matched = null;
    for (const u of users) {
      if (await verifyPin(pin, u.pin_hash)) { matched = u; break; }
    }
    checkingEl.textContent = "";

    if (!matched) {
      attempts += 1;
      pin = "";
      renderDots();
      if (attempts >= 5) {
        lockedUntil = Date.now() + 30_000;
        errorEl.textContent = "Too many attempts. Try again in 30s.";
        renderPad();
        setTimeout(() => { errorEl.textContent = ""; renderPad(); }, 30_000);
      } else {
        errorEl.textContent = `Incorrect PIN (${5 - attempts} attempts left).`;
      }
      return;
    }

    attempts = 0;
    const openShifts = await dbQuery("shifts", { cashier_id: matched.id, closed_at: null });
    if (openShifts.length > 0) {
      onLoggedIn({ id: matched.id, fullName: matched.full_name, role: matched.role, storeId: store.id, activeShift: openShifts[0] });
    } else {
      renderFloatCapture(root, matched, store, onLoggedIn);
    }
  }

  renderDots();
  renderPad();
  root.querySelector("#forgot-pin").addEventListener("click", () => renderRecoveryRequest(root, store, onLoggedIn));
}

// ---------------- PIN recovery via phone-number verification code ----------------

function generateCode() {
  return String(Math.floor(100000 + Math.random() * 900000)); // 6 digits
}

function renderRecoveryRequest(root, store, onLoggedIn) {
  root.innerHTML = `
    <div class="pin-screen">
      <div class="card" style="width:380px">
        <div class="card-body stack">
          <h2 class="text-lg font-bold">Reset your PIN</h2>
          <p class="text-sm muted">We'll generate a verification code for the phone number on file.</p>
          <div id="recovery-error" class="text-sm" style="color:var(--danger)"></div>
          <button id="send-code" class="btn">Generate verification code</button>
          <button id="recovery-cancel" class="btn-ghost text-sm">Back to PIN login</button>
        </div>
      </div>
    </div>
  `;

  root.querySelector("#recovery-cancel").addEventListener("click", () => renderPinPad(root, store, onLoggedIn));

  root.querySelector("#send-code").addEventListener("click", async () => {
    const users = await dbQuery("users", { store_id: store.id, is_active: true });
    const account = users[0];
    if (!account) {
      root.querySelector("#recovery-error").textContent = "No account found.";
      return;
    }

    const code = generateCode();
    await dbUpdate("users", account.id, {
      recovery_code: code,
      recovery_code_expires_at: new Date(Date.now() + RECOVERY_CODE_TTL_MS).toISOString(),
      updated_at: nowIso(),
    });

    renderCodeDisplay(root, store, account, code, onLoggedIn);
  });
}

function renderCodeDisplay(root, store, account, code, onLoggedIn) {
  const smsHref = `sms:${encodeURIComponent(store.phone_number || "")}?body=${encodeURIComponent(`Your Lacianda POS verification code is ${code}`)}`;

  root.innerHTML = `
    <div class="pin-screen">
      <div class="card" style="width:380px">
        <div class="card-body stack" style="text-align:center">
          <h2 class="text-lg font-bold">Your verification code</h2>
          <p class="text-sm muted">
            This app runs fully offline, so there's no SMS server to text this automatically —
            the code below is generated on this device. Note it down, or tap "Text it to myself"
            to open your phone's messaging app with it pre-filled as a record.
          </p>
          <div style="font-size:32px;font-weight:800;letter-spacing:6px;padding:14px;background:var(--muted-bg);border-radius:10px">${code}</div>
          <div class="row" style="justify-content:center;gap:8px">
            <button id="copy-code" class="btn btn-outline btn-sm">Copy code</button>
            <a href="${smsHref}" class="btn btn-outline btn-sm" style="text-decoration:none">Text it to myself</a>
          </div>
          <p class="text-sm muted">Valid for 10 minutes.</p>
          <button id="have-code" class="btn mt-1">I have the code</button>
          <button id="recovery-cancel2" class="btn-ghost text-sm">Cancel</button>
        </div>
      </div>
    </div>
  `;

  root.querySelector("#copy-code").addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(code);
      const btn = root.querySelector("#copy-code");
      const original = btn.textContent;
      btn.textContent = "Copied!";
      setTimeout(() => (btn.textContent = original), 1500);
    } catch { /* clipboard permission denied — the code is already visible on screen */ }
  });

  root.querySelector("#recovery-cancel2").addEventListener("click", () => renderPinPad(root, store, onLoggedIn));
  root.querySelector("#have-code").addEventListener("click", () => renderResetForm(root, store, account, onLoggedIn));
}

function renderResetForm(root, store, account, onLoggedIn) {
  root.innerHTML = `
    <div class="pin-screen">
      <div class="card" style="width:360px">
        <div class="card-body stack">
          <h2 class="text-lg font-bold">Enter code & new PIN</h2>
          <div>
            <label class="label">Verification code</label>
            <input id="reset-code" class="input" inputmode="numeric" maxlength="6" style="letter-spacing:4px;font-family:monospace" />
          </div>
          <div>
            <label class="label">New ${PIN_LENGTH}-digit PIN</label>
            <input id="reset-pin" class="input" type="password" inputmode="numeric" maxlength="${PIN_LENGTH}" />
          </div>
          <div>
            <label class="label">Confirm new PIN</label>
            <input id="reset-pin2" class="input" type="password" inputmode="numeric" maxlength="${PIN_LENGTH}" />
          </div>
          <div id="reset-error" class="text-sm" style="color:var(--danger)"></div>
          <button id="reset-submit" class="btn">Reset PIN & sign in</button>
        </div>
      </div>
    </div>
  `;

  root.querySelector("#reset-submit").addEventListener("click", async () => {
    const errorEl = root.querySelector("#reset-error");
    const code = root.querySelector("#reset-code").value.trim();
    const pin = root.querySelector("#reset-pin").value.trim();
    const pin2 = root.querySelector("#reset-pin2").value.trim();

    const fresh = (await dbQuery("users", { store_id: store.id, id: account.id }))[0];
    if (!fresh?.recovery_code || fresh.recovery_code !== code) {
      return (errorEl.textContent = "That code doesn't match.");
    }
    if (new Date(fresh.recovery_code_expires_at) < new Date()) {
      return (errorEl.textContent = "That code has expired — generate a new one.");
    }
    if (!/^\d{4}$/.test(pin)) return (errorEl.textContent = "PIN must be exactly 4 digits.");
    if (pin !== pin2) return (errorEl.textContent = "PINs don't match.");

    const updated = { ...fresh, pin_hash: await hashPin(pin), recovery_code: null, recovery_code_expires_at: null, updated_at: nowIso() };
    await dbUpdate("users", account.id, {
      pin_hash: updated.pin_hash, recovery_code: null, recovery_code_expires_at: null, updated_at: updated.updated_at,
    });

    // Go straight back into the app rather than reloading — same pattern
    // as a normal successful PIN login, checking for an already-open shift.
    const openShifts = await dbQuery("shifts", { cashier_id: account.id, closed_at: null });
    if (openShifts.length > 0) {
      onLoggedIn({ id: account.id, fullName: account.full_name, role: account.role, storeId: store.id, activeShift: openShifts[0] });
    } else {
      renderFloatCapture(root, account, store, onLoggedIn);
    }
  });
}

function renderFloatCapture(root, user, store, onLoggedIn) {
  root.innerHTML = `
    <div class="pin-screen">
      <div class="card" style="width:320px">
        <div class="card-body stack" style="text-align:center">
          <h2 class="text-lg font-bold">Start your shift</h2>
          <p class="muted text-sm">Enter the opening cash float for the till.</p>
          <input id="float-input" class="input" type="number" placeholder="0" autofocus style="text-align:center" />
          <button id="float-submit" class="btn btn-block">Start shift</button>
        </div>
      </div>
    </div>
  `;
  root.querySelector("#float-submit").addEventListener("click", async () => {
    const floatKes = Number(root.querySelector("#float-input").value) || 0;
    const shift = {
      id: generateId(), store_id: store.id, cashier_id: user.id,
      opening_float_cents: Math.round(floatKes * 100), opened_at: nowIso(), closed_at: null, updated_at: nowIso(),
    };
    await dbInsert("shifts", shift);
    onLoggedIn({ id: user.id, fullName: user.full_name, role: user.role, storeId: store.id, activeShift: shift });
  });
}

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
