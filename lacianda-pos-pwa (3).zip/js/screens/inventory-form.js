// js/screens/inventory-form.js — easy product entry. The default path is
// just Name + Brand + Category + Price. "Add another size" appends a new
// row without touching existing ones (earlier versions of this screen
// re-rendered everything on every add, silently wiping whatever you'd
// already typed — fixed here by appending/removing individual row
// elements instead of regenerating the whole list). "Advanced pricing"
// reveals cost price, a genuine multi-tier pricing matrix (not just one
// wholesale breakpoint), reorder level, and KRA eTIMS tax classification.

import { listCategories, listBrands, createProductWithVariants } from "../inventory.js";
import { TAX_TYPES } from "../money.js";

export async function renderInventoryFormScreen(root, user) {
  const categories = await listCategories(user.storeId);
  const brands = await listBrands(user.storeId);
  let nextVariantIdx = 0;
  let advancedMode = false;

  root.innerHTML = `
    <div class="screen-pad">
      <h1 class="text-xl font-bold mb-1">Add a product</h1>
      <p class="muted text-sm mb-3">Name, brand, category, and a price — that's all you need.</p>
      <div id="save-msg" class="text-sm mb-2" style="color:var(--success)"></div>

      <div class="card mb-2">
        <div class="card-body grid g2">
          <div style="grid-column:1/-1"><label class="label">Product name</label><input id="p-name" class="input" placeholder="Tusker Lager" autofocus /></div>
          <div>
            <label class="label">Brand</label>
            <input id="p-brand" class="input" list="brand-list" placeholder="Type an existing brand or a new one" />
            <datalist id="brand-list">${brands.map((b) => `<option value="${escapeHtml(b.name)}">`).join("")}</datalist>
          </div>
          <div>
            <label class="label">Category</label>
            <select id="p-category" class="input">
              <option value="">Select a category</option>
              ${categories.map((c) => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("")}
            </select>
          </div>
        </div>
      </div>

      <div class="card mb-2">
        <div class="card-header row-between">
          <span>Price & stock</span>
          <label class="row text-sm" style="gap:6px;cursor:pointer">
            <input type="checkbox" id="advanced-toggle" />
            Advanced pricing (cost, pricing tiers, tax type, reorder level)
          </label>
        </div>
        <div class="card-body" id="variants-container"></div>
        <div class="card-body" style="padding-top:0">
          <button id="add-variant" class="btn btn-sm btn-outline">+ Add another size / pack</button>
        </div>
      </div>

      <div id="form-error" class="text-sm mb-2" style="color:var(--danger)"></div>
      <button id="save-product" class="btn btn-lg">Save product</button>
    </div>
  `;

  const container = root.querySelector("#variants-container");

  function taxTypeOptions() {
    return Object.entries(TAX_TYPES).map(([key, t]) => `<option value="${key}">${t.label}</option>`).join("");
  }

  function tierRowHtml() {
    return `
      <div class="row tier-row" style="gap:6px;align-items:center">
        <span class="text-sm muted" style="width:70px">Qty ≥</span>
        <input class="input tier-qty" type="number" min="1" placeholder="6" style="width:70px" />
        <span class="text-sm muted">price becomes</span>
        <input class="input tier-price" type="number" placeholder="KES" style="width:100px" />
        <button type="button" class="btn-ghost btn-sm remove-tier">✕</button>
      </div>
    `;
  }

  function buildVariantRow(idx, { isFirst }) {
    const wrapper = document.createElement("div");
    wrapper.className = "variant-row";
    wrapper.dataset.variant = String(idx);
    wrapper.innerHTML = `
      ${!isFirst ? `
        <div class="row-between mb-1">
          <span class="text-sm muted font-bold">Additional size</span>
          <button type="button" class="btn-ghost btn-sm remove-variant">Remove</button>
        </div>
        <div class="mb-1"><label class="label">Size label</label><input class="input v-label" placeholder="e.g. 750ml or Crate of 25" /></div>
      ` : ""}
      <div class="grid g3 mb-1">
        <div><label class="label">Price (KES)</label><input class="input v-retail" type="number" placeholder="0" /></div>
        <div><label class="label">Barcode (optional)</label><input class="input v-barcode" placeholder="Scan or type" /></div>
        <div><label class="label">Starting stock (optional)</label><input class="input v-initial" type="number" placeholder="0" /></div>
      </div>
      <div class="advanced-fields" style="display:${advancedMode ? "block" : "none"}">
        <div class="grid g3 mb-1">
          <div><label class="label">Cost price (KES)</label><input class="input v-cost" type="number" /></div>
          <div><label class="label">Reorder level</label><input class="input v-reorder" type="number" /></div>
          <div>
            <label class="label">Tax type (eTIMS)</label>
            <select class="input v-taxtype">${taxTypeOptions()}</select>
          </div>
        </div>
        <div class="mb-1">
          <label class="label">Pricing tiers (optional — beyond the base price above)</label>
          <div class="tiers-container stack"></div>
          <button type="button" class="btn btn-sm btn-outline add-tier mt-1">+ Add price tier</button>
        </div>
      </div>
    `;

    if (!isFirst) {
      wrapper.querySelector(".remove-variant").addEventListener("click", () => wrapper.remove());
    }
    wrapper.querySelector(".add-tier").addEventListener("click", () => {
      const tiersContainer = wrapper.querySelector(".tiers-container");
      const tierEl = document.createElement("div");
      tierEl.innerHTML = tierRowHtml();
      const row = tierEl.firstElementChild;
      row.querySelector(".remove-tier").addEventListener("click", () => row.remove());
      tiersContainer.appendChild(row);
    });

    return wrapper;
  }

  function addVariantRow() {
    const isFirst = container.children.length === 0;
    container.appendChild(buildVariantRow(nextVariantIdx++, { isFirst }));
  }
  addVariantRow(); // start with one

  root.querySelector("#add-variant").addEventListener("click", addVariantRow);

  root.querySelector("#advanced-toggle").addEventListener("change", (e) => {
    advancedMode = e.target.checked;
    container.querySelectorAll(".advanced-fields").forEach((el) => { el.style.display = advancedMode ? "block" : "none"; });
  });

  root.querySelector("#save-product").addEventListener("click", async () => {
    const errorEl = root.querySelector("#form-error");
    const msgEl = root.querySelector("#save-msg");
    errorEl.textContent = ""; msgEl.textContent = "";

    const name = root.querySelector("#p-name").value.trim();
    const brandName = root.querySelector("#p-brand").value.trim();
    const categoryId = root.querySelector("#p-category").value;

    if (!name) return (errorEl.textContent = "Product name is required.");
    if (!brandName) return (errorEl.textContent = "Brand is required — type a new one if it's not listed.");
    if (!categoryId) return (errorEl.textContent = "Choose a category.");

    const rows = container.querySelectorAll(".variant-row");
    const variants = [];
    for (const [i, row] of rows.entries()) {
      const labelInput = row.querySelector(".v-label");
      const label = labelInput ? labelInput.value.trim() : "Unit";
      if (labelInput && !label) return (errorEl.textContent = "Every size needs a label (e.g. \"750ml\" or \"Crate of 25\").");
      const retailKes = Number(row.querySelector(".v-retail").value) || 0;
      if (retailKes <= 0) return (errorEl.textContent = `Enter a price for ${rows.length > 1 ? `size ${i + 1}` : "the product"}.`);

      const pricingTiers = [{ minQty: 1, priceCents: Math.round(retailKes * 100) }];
      row.querySelectorAll(".tier-row").forEach((tierRow) => {
        const minQty = Number(tierRow.querySelector(".tier-qty").value) || 0;
        const priceKes = Number(tierRow.querySelector(".tier-price").value) || 0;
        if (minQty > 1 && priceKes > 0) pricingTiers.push({ minQty, priceCents: Math.round(priceKes * 100) });
      });

      variants.push({
        variantLabel: label || "Unit",
        baseUnitsPerVariant: 1,
        barcode: row.querySelector(".v-barcode").value.trim() || undefined,
        costPriceCents: Math.round((Number(row.querySelector(".v-cost")?.value) || 0) * 100),
        retailPriceCents: Math.round(retailKes * 100),
        pricingTiers: pricingTiers.length > 1 ? pricingTiers : undefined,
        taxType: row.querySelector(".v-taxtype")?.value || "standard",
        reorderLevel: Number(row.querySelector(".v-reorder")?.value) || 0,
        initialStockBaseUnits: Number(row.querySelector(".v-initial").value) || 0,
      });
    }

    const { product } = await createProductWithVariants(user.storeId, { name, brandName, categoryId, variants });
    msgEl.textContent = `Saved "${product.name}".`;

    root.querySelector("#p-name").value = "";
    root.querySelector("#p-brand").value = "";
    root.querySelector("#p-category").value = "";
    container.innerHTML = "";
    nextVariantIdx = 0;
    addVariantRow();
    root.querySelector("#p-name").focus();
  });
}

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
