// js/screens/reports.js — end-of-day Z-Report + cash-up + shift close.

import { computeZReport, calcCashVariance } from "../reports.js";
import { formatKes } from "../money.js";
import { dbUpdate, nowIso } from "../db.js";

export async function renderReportsScreen(root, user, onShiftClosed) {
  async function load() {
    const report = await computeZReport(user.storeId, user.activeShift ? { shiftId: user.activeShift.id } : {});
    render(report);
  }

  function render(report) {
    root.innerHTML = `
      <div class="screen-pad">
        <div class="row-between mb-2">
          <h1 class="text-xl font-bold">Z-Report</h1>
          <button class="btn btn-outline btn-sm" id="refresh-report">Refresh</button>
        </div>

        <div class="card mb-2">
          <div class="card-header">Revenue summary</div>
          <div class="card-body grid g2">
            ${metric("Gross revenue", formatKes(report.grossRevenueCents), true)}
            ${metric("Completed sales", String(report.saleCount), true)}
            ${metric("Cash total", formatKes(report.cashTotalCents))}
            ${metric("M-Pesa total", formatKes(report.mpesaTotalCents))}
            ${metric("Card total", formatKes(report.cardTotalCents))}
            ${metric("Discounts given", formatKes(report.discountsGivenCents))}
            ${metric("VAT collected", formatKes(report.vatCollectedCents))}
            ${metric("Catering levy collected", formatKes(report.cateringLevyCollectedCents))}
            ${metric("Voided sales", String(report.voidedCount))}
          </div>
        </div>

        ${user.activeShift ? `
        <div class="card mb-2">
          <div class="card-header">Cash-up</div>
          <div class="card-body stack">
            ${metric("Opening float", formatKes(user.activeShift.opening_float_cents))}
            <div class="row-between">
              <label class="text-sm muted">Counted cash in drawer (KES)</label>
              <input id="counted-cash" class="input" type="number" style="width:120px;text-align:right" />
            </div>
            <div id="variance-result"></div>
            <button id="close-shift-btn" class="btn btn-outline mt-1" disabled>Close shift & log out</button>
            <p class="text-sm muted">Enter the counted cash above to enable closing this shift.</p>
          </div>
        </div>` : ""}

        <div class="card">
          <div class="card-header">Low stock — needs restocking</div>
          <div class="card-body">
            ${report.lowStockItems.length === 0
              ? `<p class="text-sm muted">Everything is above its reorder level.</p>`
              : report.lowStockItems.map((item) => `
                  <div class="row-between text-sm" style="padding:6px 0;border-bottom:1px solid var(--border)">
                    <span>${escapeHtml(item.productName)}</span>
                    <span style="color:var(--warn)">${item.quantityOnHand} on hand (reorder at ${item.reorderLevel})</span>
                  </div>
                `).join("")}
          </div>
        </div>
      </div>
    `;

    root.querySelector("#refresh-report")?.addEventListener("click", load);

    const countedInput = root.querySelector("#counted-cash");
    if (countedInput) {
      let currentVariance = null;
      countedInput.addEventListener("input", () => {
        const counted = Math.round((Number(countedInput.value) || 0) * 100);
        const { expectedCents, varianceCents } = calcCashVariance(user.activeShift.opening_float_cents, report.cashTotalCents, counted);
        currentVariance = { countedCents: counted, expectedCents, varianceCents };
        root.querySelector("#variance-result").innerHTML = `
          ${metric("Expected cash", formatKes(expectedCents))}
          ${metric("Variance", formatKes(varianceCents), false, varianceCents !== 0)}
        `;
        root.querySelector("#close-shift-btn").disabled = false;
      });

      root.querySelector("#close-shift-btn")?.addEventListener("click", async () => {
        if (!currentVariance) return;
        if (!confirm("Close this shift? You'll need to sign in again to start a new one.")) return;
        await dbUpdate("shifts", user.activeShift.id, {
          closed_at: nowIso(),
          closing_cash_cents: currentVariance.countedCents,
          expected_cash_cents: currentVariance.expectedCents,
          variance_cents: currentVariance.varianceCents,
          updated_at: nowIso(),
        });
        onShiftClosed?.();
      });
    }
  }

  function metric(label, value, big, warn) {
    return `<div><div class="text-sm muted">${label}</div><div class="${big ? "text-xl" : ""} font-bold" style="${warn ? "color:var(--warn)" : ""}">${value}</div></div>`;
  }

  await load();
}

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
