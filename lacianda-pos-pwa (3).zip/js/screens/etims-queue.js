// js/screens/etims-queue.js — sales staged for KRA eTIMS submission.
// This app can't submit to KRA directly (needs approved middleware
// regardless of architecture) — this screen is where you review what's
// pending, export it, and mark it as handled once you've submitted it
// through your actual eTIMS device/software.

import { getPendingEtimsInvoices, buildEtimsInvoice, markEtimsSubmitted } from "../etims.js";
import { formatKes } from "../money.js";
import { getFeatureFlags } from "../sales.js";
import { dbFindById } from "../db.js";

export async function renderEtimsQueueScreen(root, user) {
  const store = await dbFindById("stores", user.storeId);
  const flags = getFeatureFlags(store);

  if (!flags.etimsEnabled) {
    root.innerHTML = `
      <div class="screen-pad">
        <h1 class="text-xl font-bold mb-2">eTIMS queue</h1>
        <div class="card"><div class="card-body">
          <p class="text-sm muted">eTIMS staging isn't turned on. Enable it in Settings > KRA eTIMS to start classifying sales for tax submission.</p>
        </div></div>
      </div>
    `;
    return;
  }

  async function load() {
    const pending = await getPendingEtimsInvoices(user.storeId);
    render(pending);
  }

  function render(pending) {
    root.innerHTML = `
      <div class="screen-pad">
        <div class="row-between mb-2">
          <h1 class="text-xl font-bold">eTIMS queue</h1>
          <div class="row" style="gap:8px">
            <button id="export-json" class="btn btn-outline btn-sm" ${pending.length === 0 ? "disabled" : ""}>Export as JSON</button>
            <button id="refresh" class="btn btn-outline btn-sm">Refresh</button>
          </div>
        </div>
        <p class="text-sm muted mb-2">
          Sales below have already been classified by tax type per item. Submit them through your
          approved eTIMS device/software, then mark them submitted here to keep the queue clean.
        </p>
        <div class="card">
          <div class="card-body" style="padding:0">
            <table class="simple">
              <thead><tr><th>Receipt</th><th>Date</th><th>Taxable</th><th>VAT</th><th>Total</th><th></th></tr></thead>
              <tbody>
                ${pending.length === 0 ? `<tr><td colspan="6" class="muted" style="padding:20px;text-align:center">Nothing pending.</td></tr>` : pending.map((s) => `
                  <tr>
                    <td>${escapeHtml(s.receipt_number || s.id.slice(0, 8))}</td>
                    <td>${new Date(s.created_at).toLocaleString()}</td>
                    <td>${formatKes(s.subtotal_cents - s.discount_cents)}</td>
                    <td>${formatKes(s.vat_cents)}</td>
                    <td>${formatKes(s.total_cents)}</td>
                    <td class="row" style="gap:6px">
                      <button class="btn btn-sm btn-outline" data-view="${s.id}">View payload</button>
                      <button class="btn btn-sm" data-submitted="${s.id}">Mark submitted</button>
                    </td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    root.querySelector("#refresh").addEventListener("click", load);
    root.querySelector("#export-json").addEventListener("click", () => exportJson(pending));
    root.querySelectorAll("[data-view]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const sale = pending.find((s) => s.id === btn.dataset.view);
        const payload = await buildEtimsInvoice(user.storeId, sale);
        showPayloadModal(payload);
      });
    });
    root.querySelectorAll("[data-submitted]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        await markEtimsSubmitted(btn.dataset.submitted);
        load();
      });
    });
  }

  async function exportJson(pending) {
    const payloads = [];
    for (const s of pending) payloads.push(await buildEtimsInvoice(user.storeId, s));
    const blob = new Blob([JSON.stringify(payloads, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `etims-invoices-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function showPayloadModal(payload) {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal" style="width:500px">
        <button class="modal-close" id="pv-close">✕</button>
        <h2>Invoice ${escapeHtml(payload.invoiceNumber)}</h2>
        <pre style="background:var(--muted-bg);padding:10px;border-radius:8px;font-size:12px;overflow-x:auto;max-height:60vh">${escapeHtml(JSON.stringify(payload, null, 2))}</pre>
      </div>
    `;
    document.body.appendChild(backdrop);
    backdrop.querySelector("#pv-close").addEventListener("click", () => backdrop.remove());
  }

  await load();
}

function escapeHtml(s) {
  return (s || "").toString().replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
