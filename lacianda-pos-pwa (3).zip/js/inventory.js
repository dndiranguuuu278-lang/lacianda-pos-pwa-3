// js/inventory.js — mirrors packages/core/src/modules/inventory/*.ts from
// the full source drop: dynamic brand/category creation, multi-variant
// products sharing one stock pool, and the multi-unit conversion logic
// (a "Crate of 25" deducts 25 base units from the same pool a single
// bottle deducts 1 from).

import { dbInsert, dbUpdate, dbQuery, dbFindById, generateId, nowIso } from "./db.js";
import { CATEGORY_ORDER, CATALOG } from "./seed-data.js";

export async function getOrCreateBrand(storeId, name) {
  const trimmed = name.trim();
  const brands = await dbQuery("brands", { store_id: storeId });
  const existing = brands.find((b) => b.name.toLowerCase() === trimmed.toLowerCase());
  if (existing) return existing;
  const brand = { id: generateId(), store_id: storeId, name: trimmed, updated_at: nowIso() };
  return dbInsert("brands", brand);
}

export async function getOrCreateCategory(storeId, name, sortOrder = 0) {
  const trimmed = name.trim();
  const categories = await dbQuery("categories", { store_id: storeId });
  const existing = categories.find((c) => c.name.toLowerCase() === trimmed.toLowerCase());
  if (existing) return existing;
  const category = { id: generateId(), store_id: storeId, name: trimmed, sort_order: sortOrder, updated_at: nowIso() };
  return dbInsert("categories", category);
}

export async function listCategories(storeId) {
  const rows = await dbQuery("categories", { store_id: storeId });
  return rows.sort((a, b) => a.sort_order - b.sort_order);
}

export async function listBrands(storeId) {
  return dbQuery("brands", { store_id: storeId });
}

export async function createProductWithVariants(storeId, { name, brandName, categoryId, variants }) {
  const brand = await getOrCreateBrand(storeId, brandName);
  const now = nowIso();

  const product = {
    id: generateId(), store_id: storeId, brand_id: brand.id, category_id: categoryId,
    name: name.trim(), is_active: true, updated_at: now,
  };
  await dbInsert("products", product);

  const savedVariants = [];
  for (const v of variants) {
    const variant = {
      id: generateId(), store_id: storeId, product_id: product.id,
      variant_label: v.variantLabel.trim(), volume_ml: v.volumeMl ?? null,
      barcode: v.barcode?.trim() || null, base_units_per_variant: Math.max(1, v.baseUnitsPerVariant || 1),
      cost_price_cents: v.costPriceCents || 0, retail_price_cents: v.retailPriceCents || 0,
      wholesale_price_cents: v.wholesalePriceCents || 0, wholesale_qty_threshold: v.wholesaleQtyThreshold ?? null,
      pricing_tiers: Array.isArray(v.pricingTiers) && v.pricingTiers.length ? v.pricingTiers : null,
      tax_type: v.taxType || "standard", // 'standard' | 'zero_rated' | 'exempt' — KRA eTIMS classification
      reorder_level: v.reorderLevel ?? 0, is_active: true, updated_at: now,
    };
    await dbInsert("product_variants", variant);
    savedVariants.push(variant);
  }

  const initialUnits = variants.find((v) => v.initialStockBaseUnits)?.initialStockBaseUnits ?? 0;
  await dbInsert("inventory_stock", {
    id: generateId(), store_id: storeId, product_id: product.id, quantity_on_hand: initialUnits, updated_at: now,
  });

  return { product, variants: savedVariants };
}

export async function findVariantByBarcode(storeId, barcode) {
  const rows = await dbQuery("product_variants", { store_id: storeId, barcode });
  return rows[0] ?? null;
}

export async function listProductsWithVariants(storeId, categoryId) {
  const products = await dbQuery("products", categoryId ? { store_id: storeId, category_id: categoryId } : { store_id: storeId });
  const out = [];
  for (const p of products.filter((p) => p.is_active !== false)) {
    const variants = (await dbQuery("product_variants", { product_id: p.id })).filter((v) => v.is_active !== false);
    out.push({ ...p, variants });
  }
  return out;
}

// -------- Stock (multi-unit conversion) --------

async function getStockRow(storeId, productId) {
  const rows = await dbQuery("inventory_stock", { store_id: storeId, product_id: productId });
  if (rows[0]) return rows[0];
  const fresh = { id: generateId(), store_id: storeId, product_id: productId, quantity_on_hand: 0, updated_at: nowIso() };
  await dbInsert("inventory_stock", fresh);
  return fresh;
}

async function writeMovement(storeId, productId, variantId, changeQty, reason, referenceId, createdBy) {
  await dbInsert("stock_movements", {
    id: generateId(), store_id: storeId, product_id: productId, variant_id: variantId,
    change_qty: changeQty, reason, reference_id: referenceId, created_by: createdBy,
    created_at: nowIso(), updated_at: nowIso(),
  });
}

export class InsufficientStockError extends Error {
  constructor(productId, requested, available) {
    super(`Insufficient stock: requested ${requested}, have ${available}`);
    this.name = "InsufficientStockError";
    this.productId = productId;
  }
}

/** quantitySold is in VARIANT units (e.g. 2 crates); converts to base units before deducting. */
export async function deductStockForSale(storeId, variant, quantitySold, saleId, cashierId, allowNegative = false) {
  const baseUnits = quantitySold * variant.base_units_per_variant;
  const stock = await getStockRow(storeId, variant.product_id);
  if (!allowNegative && stock.quantity_on_hand < baseUnits) {
    throw new InsufficientStockError(variant.product_id, baseUnits, stock.quantity_on_hand);
  }
  const newQty = stock.quantity_on_hand - baseUnits;
  await dbUpdate("inventory_stock", stock.id, { quantity_on_hand: newQty, updated_at: nowIso() });
  await writeMovement(storeId, variant.product_id, variant.id, -baseUnits, "sale", saleId, cashierId);
  return newQty;
}

export async function restockVariant(storeId, variant, quantityReceived, createdBy, reason = "restock") {
  const baseUnits = quantityReceived * variant.base_units_per_variant;
  const stock = await getStockRow(storeId, variant.product_id);
  const newQty = stock.quantity_on_hand + baseUnits;
  await dbUpdate("inventory_stock", stock.id, { quantity_on_hand: newQty, updated_at: nowIso() });
  await writeMovement(storeId, variant.product_id, variant.id, baseUnits, reason, null, createdBy);
  return newQty;
}

/**
 * Dynamic tiered pricing matrix: a variant can define ANY number of price
 * tiers (not just retail/wholesale), e.g. 1+ = 200, 6+ = 180, 12+ = 160,
 * 24+ = 145. Resolves to the highest tier whose minQty <= the quantity
 * being sold. Falls back to the older single retail/wholesale/threshold
 * fields for products created before tiers existed, so nothing breaks.
 */
export function getPricingTiers(variant) {
  if (Array.isArray(variant.pricing_tiers) && variant.pricing_tiers.length > 0) {
    return [...variant.pricing_tiers].sort((a, b) => a.minQty - b.minQty);
  }
  const tiers = [{ minQty: 1, priceCents: variant.retail_price_cents }];
  if (variant.wholesale_qty_threshold > 0 && variant.wholesale_price_cents > 0) {
    tiers.push({ minQty: variant.wholesale_qty_threshold, priceCents: variant.wholesale_price_cents });
  }
  return tiers;
}

export function resolveUnitPrice(variant, quantity) {
  const tiers = getPricingTiers(variant);
  let chosen = tiers[0];
  for (const t of tiers) {
    if (quantity >= t.minQty) chosen = t;
  }
  return {
    unitPriceCents: chosen.priceCents,
    isWholesale: chosen.minQty > 1,
    tierLabel: chosen.minQty > 1 ? `${chosen.minQty}+` : null,
  };
}

export async function getLowStockProducts(storeId) {
  const stockRows = await dbQuery("inventory_stock", { store_id: storeId });
  const variants = await dbQuery("product_variants", { store_id: storeId });
  const reorderByProduct = new Map();
  for (const v of variants) {
    reorderByProduct.set(v.product_id, Math.max(reorderByProduct.get(v.product_id) ?? 0, v.reorder_level || 0));
  }
  const out = [];
  for (const s of stockRows) {
    const reorderLevel = reorderByProduct.get(s.product_id) ?? 0;
    if (s.quantity_on_hand <= reorderLevel) {
      const product = await dbFindById("products", s.product_id);
      out.push({ productName: product?.name ?? "Unknown", quantityOnHand: s.quantity_on_hand, reorderLevel });
    }
  }
  return out;
}

// -------- Seeding --------

export async function seedCatalogIfEmpty(storeId) {
  const existing = await dbQuery("products", { store_id: storeId });
  if (existing.length > 0) return;

  const categoryIds = {};
  for (const [i, name] of CATEGORY_ORDER.entries()) {
    const cat = await getOrCreateCategory(storeId, name, i);
    categoryIds[name] = cat.id;
  }

  for (const item of CATALOG) {
    const variants = item.variants.map((v) => ({
      variantLabel: v.variantLabel, volumeMl: v.volumeMl, baseUnitsPerVariant: v.baseUnits,
      costPriceCents: Math.round(v.costKes * 100), retailPriceCents: Math.round(v.retailKes * 100),
      wholesalePriceCents: Math.round(v.wholesaleKes * 100), wholesaleQtyThreshold: v.wholesaleQtyThreshold,
      reorderLevel: v.reorderLevel, initialStockBaseUnits: v.initialStock,
    }));
    await createProductWithVariants(storeId, { name: item.name, brandName: item.brand, categoryId: categoryIds[item.category], variants });
  }
}
